<html>
	<head>
		<title><?php echo "Dynamisch"; ?></title>
	</head>
	<body>
<?php
$test = 1.34324;
echo $test."<br />";

$test = "Testwort";
echo intval($test)."<br />";

$test = true;
echo $test."<br />";


?>
<table>
<?php
	for($i = 0; $i < 40; $i++){
		echo "<tr>";
		for($j = 0; $j < 40; $j++){
			if($i%2==0)
				$bgcolor = "#eeeeee";
			else
				$bgcolor = "#dddddd";
			echo "<td  bgcolor=\"".$bgcolor."\" >".$i."/".$j."</td>\n";
		}
		echo "</tr>\n";
	}
?>
</table>
</body>

</html>
