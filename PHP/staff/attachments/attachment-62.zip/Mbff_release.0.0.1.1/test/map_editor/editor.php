<?php

function set_tile($x, $y , $s, $item){
	global $map;
	if($map[$x][$y]['m'] != $item){
		$map[$x][$y][$s] = $item;
	}
}
$filename = "map_static.msf";
include($filename);
/*
 INIT
*/
if($_REQUEST['item'])
	$item = $_REQUEST['item'];
else
	$item = "w";
if($_REQUEST['x'])
	$s_x = $_REQUEST['x'];

if($_REQUEST['y'])
	$s_y = $_REQUEST['y'];

if($_REQUEST['item'] && (!$_REQUEST['x'] || $_REQUEST['x'] == "") && $_REQUEST['new'] != 1)
	$s_x = 0;

if($_REQUEST['item'] && (!$_REQUEST['y'] || $_REQUEST['y'] == "") && $_REQUEST['new'] != 1)
	$s_y = 0;
/*
 Berarbeiten
*/

$map[$s_x][$s_y] = array("m" => $item, "u" => $item, "o" => $item, "r" => $item, "l" => $item);


if($s_y%2 == 0){
	//unten
	set_tile($s_x, $s_y-1 , 'u', $item);
	//$map[$s_x][$s_y-1]['u'] = $item;
	//rechts
	set_tile($s_x-1, $s_y-1 , 'r', $item);
	//$map[$s_x-1][$s_y-1]['r'] = $item;
	//oben
	set_tile($s_x-1, $s_y+1, 'o', $item);
	//$map[$s_x-1][$s_y+1]['o'] = $item;
	//links
	set_tile($s_x, $s_y+1 , 'l', $item);
	//$map[$s_x][$s_y+1]['l'] = $item;
}else{
	//unten
	set_tile($s_x+1, $s_y-1 , 'u', $item);
	//$map[$s_x+1][$s_y-1]['u'] = $item;
	//rechts
	set_tile($s_x, $s_y-1 , 'r', $item);
	//$map[$s_x][$s_y-1]['r'] = $item;
	//oben
	set_tile($s_x, $s_y+1 , 'o', $item);
	//$map[$s_x][$s_y+1]['o'] = $item;
	//links
	set_tile($s_x+1, $s_y+1 , 'l', $item);
	//$map[$s_x+1][$s_y+1]['l'] = $item;
}

/*
 Darstellung
*/

echo "------------| Tile Typ: ".$item;
if($s_x && $s_y)
	echo " |---------------------| Setze ".$s_x."/".$s_y." auf ".$item; 
echo " |------------<br />";
$tile_height  = $sys['xpos'] = $sys['ypos'] = 0;
$xspacer = 50;
$yspacer = 40;
$w = 70; 
$h = 35;
$w2 = floor($w/2);
$h2 = floor($h/2);

$layer = $pic = 0;

$offset = 1;
for($y = 0; $y < 45; $y++){
	$layer++;
	for($x = 0; $x < 15; $x++){
		if($y % 2 == 0)
			$sys['xpos'] = $xspacer - $w2 + ($w) * $x ;
		else
			$sys['xpos'] = $xspacer + ($w ) * $x;
			
		$sys['ypos'] = $yspacer + $y*($h2 + $offset) - $tile_height; 
		$para = $map[$x][$y];
		echo "<div style=\"color:#ffffff; text-align:center; vertical-align:top; background-image:url(tile.php?m=".$para['m']."&o=".$para['o']."&u=".$para['u']."&l=".$para['l']."&r=".$para['r']."); position:absolute; z-index:".$layer."; width:70px; height:35px; left:".$sys['xpos']."px;top:".$sys['ypos']."px;\">\n";
		echo "<span style=\"font-size:2;\"><br /></span><a style=\"text-decoration:none;\" name=\"bild".$pic."\" title=\"".$x."/".$y." auf ".$item." setzen\" href=\"editor.php?item=".$item."&x=".$x."&y=".$y."\">M</a><span style=\"font-size:10;\"><br />".$x."/".$y."</span>\n";
		echo "</div>\n";			
	}
	$pic++;
}


/*
 Speichern
*/

$content = "<?php\r\n";
for($y = 0; $y < 45; $y++)
	for($x = 0; $x < 15; $x++)
		$content .= "\$map[".$x."][".$y."] = array(\"l\" => \"".$map[$x][$y]['l']."\", \"o\" => \"".$map[$x][$y]['o']."\", \"r\" => \"".$map[$x][$y]['r']."\", \"u\" => \"".$map[$x][$y]['u']."\", \"m\" => \"".$map[$x][$y]['m']."\"); //".++$i."\r\n";
$content .= "?>\r\n";

echo "<div style=\"text-align:center; vertical-align:top; position:absolute; z-index:1; width:100%; left:100px;top:1024px;\"><hr />";
if($handle = @fopen ($filename, "w+")){
	if(fwrite($handle,  $content))
		echo "-------Daten geschrieben-------";
	fclose($handle);
}
echo "<hr />";
echo "</div>";

?>