<?php
$f['m'] = 'w';
$f['l'] = '_';
$f['r'] = '_';
$f['o'] = '_';
$f['u'] = '_';
$seiten = array('m', 'l', 'r', 'o', 'u');
foreach($seiten as $seite)
	if($_REQUEST[$seite])
		$f[$seite] = $_REQUEST[$seite];

$filename = "tiles/".$f['m']."_".$f['l']."_".$f['r']."_".$f['o']."_".$f['u'].".png";


//$tile = imagecreatetruecolor(70, 35);
if($f['m'] == "i"){
	$bgimg = imagecreatetruecolor(70, 35);
	$col['i'] = ImageColorAllocate($tile, 206, 238, 255);
	imagefill($tile, 0, 0, $col[$f['m']]);
	//$tile = imagecreatefrompng("i.png");
}
elseif($f['m'] == "l")
	$bgimg = imagecreatefrompng("l.png");
elseif($f['m'] == "m")
	$bgimg = imagecreatefrompng("m.png");
elseif($f['m'] == "d")
	$bgimg = imagecreatefrompng("d.png");
elseif($f['m'] == "f")
	$bgimg = imagecreatefrompng("f.png");
elseif($f['m'] == "n")
	$bgimg = imagecreatefrompng("n.png");

else
	$bgimg = imagecreatefrompng("w.png");

imagetruecolortopalette ($bgimg, true, 256);

//$tile = imagecreatetruecolor(40, 40);
//ImageCopy($tile, $bgimg,  0, 0, 0, 0, 40, 40);
$trans = ImageColorAllocate($bgimg, 254, 254, 254);

imagerotate($bgimg, 45, $trans);


//$tile = imagecreatetruecolor(70, 35);
//
//ImageCopy ( int dst_im, int src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h)
//ImageCopy($tile, $bgimg,  0, 0, 0, 0, 70, 35);
//
//$white = ImageColorAllocate($tile, 255, 255, 255);
//$black = ImageColorAllocate($tile, 0, 0, 0);
//$yellow = ImageColorAllocate($tile, 255, 255, 0);
//$trans = ImageColorAllocate($tile, 254, 254, 254);
//
//$col['w'] = ImageColorAllocate($tile, 45, 167, 242);
//$col['n'] = ImageColorAllocate($tile, 33, 119, 31);
//$col['m'] = ImageColorAllocate($tile, 114, 115, 109);
//
//$col['l'] = ImageColorAllocate($tile, 115, 191, 54);
//
//$col['f'] = ImageColorAllocate($tile, 130, 50, 11);
//
//$col['d'] = ImageColorAllocate($tile, 233, 223, 191);
//$col['i'] = ImageColorAllocate($tile, 206, 238, 255);
//
//
//
//
//
//$trans = imagecolortransparent($tile, $trans);

////Ecke links oben
//imagefilledpolygon ($tile, array("0", "17", "0", "0", "35", "0", "0", "17"), 4, $trans);
//
////Ecke rechts oben
//imagefilledpolygon ($tile, array("35", "0", "70", "0", "70", "17", "35", "0"), 4, $trans);
//
////Ecke rechts unten
//imagefilledpolygon ($tile, array("70", "17", "70", "35", "35", "35", "70", "17"), 4, $trans);
//
////Ecke links unten
//imagefilledpolygon ($tile, array("35", "35", "0", "17", "0", "35", "35", "35"), 4, $trans);


imageinterlace($bgimg,1);

header("Content-Type: image/png");
$file = $bgimg;
imagepng($file, $filename);

imagepng($bgimg);
imagedestroy($bgimg);

?>