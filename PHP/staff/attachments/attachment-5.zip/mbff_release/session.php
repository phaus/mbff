<?php
	@extract($_REQUEST);
	@extract($_POST);
	if($user_id)
		$sid = getnewsid();		
	elseif($user_id = is_sid_activ($sid)){
		$user = new c_user($user_id);
		update_session($sid, $user_id);
		$hp['title'] = $user->data['username']."@";
	}elseif($sid){
		$user_id = -2;
	}else{
		$user_id = -1;
		$sid = getnewsid();
	}
?>