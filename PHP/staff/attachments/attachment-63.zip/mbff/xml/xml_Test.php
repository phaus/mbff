<?php

header("Content-Type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n";
echo "<test></test>";
?>