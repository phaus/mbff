<?php
##################################################################################
$modules = array("system", "system_list");
$funcs = array();
$get = array();
$request = array();
$post = array();
##################################################################################
require("./session.php");

header("Content-Type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n";
echo "<mbff typ=\"galaxy\">\n";

if($user_id > 0){
	echo "<sid>$sid</sid>\n";
	echo "<systems>\n";
	$sys_list = new c_system_list("*");
	$sys_list->get_all_nodes(array('system_name', 'system_location'));
	$sys_arr = $sys_list->return_data_array();
	foreach($sys_arr as $sys){
		echo "<system>\n";
		echo "<id>".$sys['system_id']."</id>\n";
		echo "<name>".$sys['system_name']."</name>\n";
		$koords = unserialize($sys['system_location']);
		echo "<koords>\n";
		echo "<x>".$koords[0]."</x>\n";
		echo "<y>".$koords[1]."</y>\n";
		echo "<z>".$koords[2]."</z>\n";
		echo "</koords>\n";
		echo "</system>\n";
	}
	echo "</systems>\n";
}else{
	echo "<sid>-1</sid>\n";
	echo "<error>NO USER LOGIN</error>\n";
}
echo "</mbff>\n";
?>