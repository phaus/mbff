<?php
require("./include/base_functions.php");
require("./session.php");


if($user_id > 0){
	$sys_db = new db($sys_conf['db_level1']['host'], $sys_conf['db_level1']['user'], $sys_conf['db_level1']['pass'], $sys_conf['db_level1']['name'],$phpversion);
	$sql = "SELECT system_id, system_name, system_location 
			FROM systems_index";
	$result = $sys_db->query($sql);
	while($sys = $sys_db->fetch_array($result, MYSQL_ASSOC)){
		$koords = unserialize($sys['system_location']);
		$sys['x'] = $koords[0] + 100;
		$sys['y'] = $koords[1] + 50;
		eval("\$hp['systems']  .= \"".hp_gettemplate("game_galaxy_bit", $sys_conf['lang'])."\";");
	}

	eval("\$hp['content']  = \"".hp_gettemplate("game_galaxy", $sys_conf['lang'])."\";");
	eval("\$hp['menu_main']  = \"".hp_gettemplate("main_links", $sys_conf['lang'])."\";");		
	eval("\$hp['nav']  = \"".hp_gettemplate("menu_main", $sys_conf['lang'])."\";");	
}else{
	$hp['style'] = "background-image: url(images/t.space.gif);";
	eval("\$hp['content']  = \"".hp_gettemplate("login", $sys_conf['lang'])."\";");
}
///////////////////////////////////////////

eval("\$index = \"".hp_gettemplate("index", $sys_conf['lang'])."\";");
echo $index;
?>
