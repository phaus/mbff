<?php
##################################################################################
$modules = array();
$funcs = array();
$get = array();
$request = array();
$post = array();
##################################################################################
require("./session.php");
header("Content-Type: text/xml");
echo"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
echo "<mbff typ=\"info\">\n";
if($user_id > 0){
	echo "<sid>$sid</sid>\n";
	echo "<user>\n";
		foreach($user as $key => $part){
			if($key != "password")
				echo "<data key=\"".$key."\">".$part."</data>\n";
		}
	echo "</user>\n";
}else{
	echo "<sid>-1</sid>\n";
	echo "<error>Sie sind nicht angemeldet !</error>\n";
}
echo "</mbff>\n";
?>