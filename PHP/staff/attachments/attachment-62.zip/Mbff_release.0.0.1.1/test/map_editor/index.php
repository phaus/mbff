<html>
	<head>
		<title>MBFF Map Editor</title>
		<frameset cols="100,*">
			<frame src="nav.htm" name="Navigation" />
			<frame src="preview.php" name="EditWindow" />
		</frameset>
	</head>
	<body>
		<i>Darstellung <b>ohne</b> Frames Unterst�tzung <b>nicht</b> m�glich !</i>
	</body>
</html>