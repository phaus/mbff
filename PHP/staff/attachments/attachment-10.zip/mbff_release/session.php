<?php
	@extract($_REQUEST);
	@extract($_POST);
	if($HTTP_COOKIE_VARS[$sys_conf['string']])
		$sid = $HTTP_COOKIE_VARS[$sys_conf['string']];
	$hp['user'] = "Gast";
	if($user_id)
		$sid = getnewsid();		
	elseif($user_id = is_sid_activ($sid)){
		$c_user = new c_user($user_id);
		$c_user->get_data();
		$user = $c_user->return_data_array();
		update_session($sid, $user_id);
		$hp['user'] = $user['username'];
	}elseif($sid){
		$user_id = -2;
	}else{
		$user_id = -1;
		$sid = getnewsid();
	}

?>