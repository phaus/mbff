<?php
require("./admin/account_functions.php");
require("./admin/char_functions.php");
require("./global.php");
$des_id = 3;
$t_width = "100%";
$t_height = "100%";
$max_step = 8;
if($_REQUEST['step']){
    $step     = $_REQUEST['step'];
} else {
    $step     = 1;
}

if($_REQUEST['stats']){
    $stats    = $_REQUEST['stats'];
} else {
    $stats = 0;
}

//nicht eingeloggt
if(!$wbbuserdata['userid']){
exit;
}

//zu viele Chars
$sql = "SELECT * FROM ".$hp_options['db_sys_chars']." WHERE char_account_id = '".$wbbuserdata['userid']."' AND char_type='1'";
$result = $db-> query($sql);
if($db -> num_rows($result) > $hp_options['normal_char_limit']){
exit;
}

$oben_title_r = "<input title=\"untere Seite\" onClick=\"self.location.href='#unten'\"  class=\"input\" type=\"button\" value=\"&gt;runter&lt;\" />\n";
$link['header'] = "<big><b>neuen Character erstellen</b></big><br /><b><a href='account.php?action=chars'>&laquo; back</a> Char&uuml;bersicht von '".$wbbuserdata['username']."' (ID".$wbbuserdata['userid']."):</b>";
$link['step'] = "<h2>Schritt (".$step." von ".$max_step."):</h2>";
switch($step){

//8. abschluss
case"8":
eval("\$link['left'] = \"".hp_gettemplate("hp_chargen8")."\";");
eval("\$link['footer'] .= \"".hp_gettemplate("hp_next_n_back")."\";");
break;

//7. Charstory
case"7":
eval("\$link['js'] = \"".hp_gettemplate("hp_js_textcount")."\";");
eval("\$link['left'] = \"".hp_gettemplate("hp_chargen7")."\";");
eval("\$link['footer'] .= \"".hp_gettemplate("hp_next_n_back")."\";");
break;

//6. Schritt
case"6":
$link['left'] .= "<form action=\"chargen.php?step=7\" method=\"post\">\n";
//eval("\$c_info = \"".hp_gettemplate("hp_chargeninfo")."\";");
$bodygump = "female.gif";
$layer["right_hand"] = get_layerdrop(1);
$layer["left_hand"] = get_layerdrop(2);
$layer["shoes"] = get_layerdrop(3);
$layer["leg_cover"] = get_layerdrop(4);
if($bodygump == "female.gif"){
    $layer["chest"] = get_layerdrop(5);
}
$layer["head"] = get_layerdrop(6);
$layer["ring"] = get_layerdrop(8);
$layer["neck"] = get_layerdrop(10);
$layer["waist"] = get_layerdrop(12);
$layer["body1"] = get_layerdrop(13);
$layer["bracelet"] = get_layerdrop(14);
$layer["body2"] = get_layerdrop(17);
$layer["back"] = get_layerdrop(20);
$layer["body3"] = get_layerdrop(22);
$layer["legs1"] = get_layerdrop(23);
$layer["legs2"] = get_layerdrop(24);
eval("\$link['left'] .= \"".hp_gettemplate("hp_charequip")."\";");
eval("\$link['footer'] = \"".hp_gettemplate("hp_next_n_back")."\";");
break;

//5. Schritt
case"5":
$link['footer'] .= "<form action=\"chargen.php?step=6\" method=\"post\">\n";
if($_POST["go"]){
    $char=$_POST;
}
$link['footer'] .= "<h2><i>aktuelle</i> Charakter Skills:</h2>";
$char = char_skills($char);
eval("\$link['footer'] .= \"".hp_gettemplate("hp_chargenstat")."\";");
eval("\$link['footer'] .= \"".hp_gettemplate("hp_next_n_back")."\";");
break;

//4. vorteile
case"4":
eval("\$link['left'] = \"".hp_gettemplate("hp_chargen4")."\";");
eval("\$link['footer'] .= \"".hp_gettemplate("hp_next_n_back")."\";");
break;


//3. Nachteile
case"3":
eval("\$link['left'] = \"".hp_gettemplate("hp_chargen3")."\";");
eval("\$link['footer'] .= \"".hp_gettemplate("hp_next_n_back")."\";");
break;

//2. Schritt
case"2":
eval("\$link['footer'] = \"".hp_gettemplate("hp_next_n_back")."\";");
$link["left"] = char_attr($char["char_raceid"] = -1);
break;

//START
default:
$char['char_rasse'] = do_groupdrop("char_race", $char["char_race"], $char["char_raceid"]);
eval("\$link['left'] = \"".hp_gettemplate("hp_chargen1")."\";");
eval("\$link['footer'] = \"".hp_gettemplate("hp_next")."\";");
$unten = "</form>";
}

if($stats == 1){
eval("\$link['footer'] .= \"".hp_gettemplate("hp_chargenstat")."\";");
}
//eval("\$link['right'] = \"".hp_gettemplate("hp_chargeninfo")."\";");


eval("\$oben = \"".hp_gettemplate("hp_scrolloben")."\";");
eval("\$unten .= \"".hp_gettemplate("hp_scrollunten")."\";");
eval("\$out .= \"".hp_gettemplate("hp_chargen")."\";");
echo $out;

?>