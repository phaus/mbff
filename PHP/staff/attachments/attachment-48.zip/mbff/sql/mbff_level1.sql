# MySQL-Front Dump 2.5
#
# Host: localhost   Database: mbff_level1
# --------------------------------------------------------
# Server version 4.0.20a-nt-log


#
# Table structure for table 'sessions'
#

CREATE TABLE sessions (
  sid varchar(32) default '0',
  ip varchar(30) default NULL,
  user_id int(15) unsigned default '0',
  session_start int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Table structure for table 'sessions_value'
#

CREATE TABLE sessions_value (
  sid varchar(32) default '0',
  session_value_name varchar(50) default '0',
  session_value text
) TYPE=MyISAM;



#
# Table structure for table 'system_table'
#

CREATE TABLE system_table (
  system_id int(10) unsigned default '0',
  category varchar(100) default '0',
  value text
) TYPE=MyISAM;



#
# Table structure for table 'user_table'
#

CREATE TABLE user_table (
  user_id int(10) unsigned default '0',
  category varchar(100) default '0',
  value text
) TYPE=MyISAM;

