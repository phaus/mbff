<?php
require("./include/base_functions.php");
require("./session.php");
$hp['footer'] = hp_compressed_output();

if($user_id > 0){
	$hp['style'] = "background-image: url(../../images/t.space.gif);";
	$hp['interface_info'] = "Info";
	
	$system = new c_system($sys_id);
	$hp['system_name'] = $system->data['system_name'];
	eval("\$hp['interface_side'] = \"".hp_gettemplate("map_nav_links")."\";");
	eval("\$hp['interface_top'] = \"".hp_gettemplate("map_nav_top")."\";");
	eval("\$hp['js'] = \"".hp_gettemplate("menu_lo_js")."\";");
	eval("\$hp['nav'] = \"".hp_gettemplate("menu_lo")."\";");
	$w = 70; 
	$h = 35;
	$w2 = ceil($w/2);
	$h2 = ceil($h/2);
	$layer = $pic = 0;
	$offset = 1;
	for($y = 0; $y < 45; $y++){
		$layer++;
		for($x = 0; $x < 15; $x++){
			if($y % 2 == 0)
				$sys['xpos'] = 150 - $w2 + ($w) * $x ;
			else
				$sys['xpos'] = 150 + ($w ) * $x;
			
			$sys['ypos'] = 125 + $y*($h2 + $offset) - $tile_height; 
			$pic++;
			eval("\$hp['system_bit']  .= \"".hp_gettemplate("game_system_map_bit")."\";");
		}
	}
	eval("\$hp['content']  = \"".hp_gettemplate("game_system_map")."\";");


	eval("\$hp['js'] = \"".hp_gettemplate("menu_lo_js")."\";");
	$layer++;
	eval("\$hp['nav'] = \"".hp_gettemplate("menu_lo")."\";");

	eval("\$index = \"".hp_gettemplate("field")."\";");
	echo $index;
}else{
	eval("\$hp['content']  = \"".hp_gettemplate("login")."\";");
	eval("\$index = \"".hp_gettemplate("index")."\";");
	echo $index;
}


///////////////////////////////////////////

?>
