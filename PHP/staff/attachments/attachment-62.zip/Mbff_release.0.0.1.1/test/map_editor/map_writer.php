<?php

function make_image($f){
	$seiten = array('m', 'l', 'r', 'o', 'u');		
	$presets = array('m' => 'w', 'l' => '_', 'r' => '_', 'o' => '_', 'u' => '_');
	foreach($seiten as $seite)
		if($f[$seite])
			$f[$seite] = $f[$seite];
		else
			$f[$seite] = $presets[$seite];
			
	$filename = "tiles/".$f['m']."_".$f['l']."_".$f['r']."_".$f['o']."_".$f['u'].".png";
	
	
	if($f['m'] == "i"){
		$bgimg = imagecreatetruecolor(70, 35);
		$col['i'] = ImageColorAllocate($tile, 206, 238, 255);
		imagefill($tile, 0, 0, $col[$f['m']]);
	}
	elseif($f['m'] == "l")
		$bgimg = imagecreatefrompng("l.png");
	elseif($f['m'] == "m")
		$bgimg = imagecreatefrompng("m.png");
	elseif($f['m'] == "d")
		$bgimg = imagecreatefrompng("d.png");
	elseif($f['m'] == "f")
		$bgimg = imagecreatefrompng("f.png");
	elseif($f['m'] == "n")
		$bgimg = imagecreatefrompng("n.png");
	
	else
		$bgimg = imagecreatefrompng("w.png");
	
	$trans = ImageColorAllocate($bgimg, 254, 254, 254);
	
	imagerotate ($bgimg, 30, $trans);
	
	
	$tile = imagecreatetruecolor(70, 35);
	
	ImageCopy($tile, $bgimg,  0, 0, 0, 0, 70, 35);
	
	$white = ImageColorAllocate($tile, 255, 255, 255);
	$black = ImageColorAllocate($tile, 0, 0, 0);
	$yellow = ImageColorAllocate($tile, 255, 255, 0);
	$trans = ImageColorAllocate($tile, 254, 254, 254);
	
	$col['w'] = ImageColorAllocate($tile, 45, 167, 242);
	$col['n'] = ImageColorAllocate($tile, 33, 119, 31);
	$col['m'] = ImageColorAllocate($tile, 114, 115, 109);
	
	$col['l'] = ImageColorAllocate($tile, 115, 191, 54);
	
	$col['f'] = ImageColorAllocate($tile, 130, 50, 11);
	
	$col['d'] = ImageColorAllocate($tile, 233, 223, 191);
	$col['i'] = ImageColorAllocate($tile, 206, 238, 255);
	
	$trans = imagecolortransparent($tile, $trans);
	
	//Bogen oben
	$s = 2*-26.57;
	if($f['l'] != '_')
	imagefilledarc($tile, 0, 0, 85, 35, $s, $s + 180, $col[$f['l']], IMG_ARC_PIE);
	
	//Bogen links
	$s = $s + 90;
	if($f['o'] != '_')
	imagefilledarc($tile, 70, 0, 85, 35, $s, $s + 180, $col[$f['o']], IMG_ARC_PIE);
	
	//Bogen rechts
	$s = $s + 90;
	if($f['r'] != '_')
	imagefilledarc($tile, 70, 35, 85, 35, $s, $s + 180, $col[$f['r']], IMG_ARC_PIE);
	
	//Bogen unten
	$s = $s + 90;
	if($f['u'] != '_')
	imagefilledarc($tile, 0, 35, 85, 35, $s, $s + 180, $col[$f['u']], IMG_ARC_PIE);
		
	
	
//	//Ecke links oben
//	imagefilledpolygon ($tile, array("0", "17", "0", "0", "35", "0", "0", "17"), 4, $trans);
//	
//	//Ecke rechts oben
//	imagefilledpolygon ($tile, array("35", "0", "70", "0", "70", "17", "35", "0"), 4, $trans);
//	
//	//Ecke rechts unten
//	imagefilledpolygon ($tile, array("70", "17", "70", "35", "35", "35", "70", "17"), 4, $trans);
//	
//	//Ecke links unten
//	imagefilledpolygon ($tile, array("35", "35", "0", "17", "0", "35", "35", "35"), 4, $trans);
	
	
	imageinterlace($tile,1);
	return $tile;
}

$w = 70; 
$h = 35;

$img_x = 15 * $w + $w/2;	
$img_y = 44 * $h/2 + $h/2;

$filename = "map_static.msf";
include($filename);
//print_r($map);
$img_map = imagecreatetruecolor($img_x, $img_y);
$trans = ImageColorAllocate($img_map, 254, 254, 254);
imagefill($img_map, 0, 0, $trans);

$tile_height  = $sys['xpos'] = $sys['ypos'] = 0;
$xspacer = 35;
$w2 = floor($w/2);
$h2 = floor($h/2);

for($y = 0; $y < 45; $y++){
	$layer++;
	for($x = 0; $x < 15; $x++){
		$tile = make_image($map[$x][$y]);

		if($y % 2 == 0)
			$sys['xpos'] = $xspacer - $w2 + ($w) * $x ;
		else
			$sys['xpos'] = $xspacer + ($w ) * $x;
			
		$sys['ypos'] = $yspacer + $y*($h2 + $offset); 
		ImageCopy($img_map, $tile,  $sys['xpos'], $sys['ypos'], 0, 0, 70, 35);
		imagedestroy($tile);
	}
}
$trans = imagecolortransparent($img_map, $trans);
header("Content-Type: image/png");
imagepng($img_map);
imagedestroy($img_map);
?>