<?php

// this example is provided by poxy at klam dot is

// create image
$image = imagecreate(700,350);

// allocate some solors
$white    = imagecolorallocate($image, 0xFF, 0xFF, 0xFF);
$gray     = imagecolorallocate($image, 0xC0, 0xC0, 0xC0);
$darkgray = imagecolorallocate($image, 0x90, 0x90, 0x90);
$f['o']     = imagecolorallocate($image, 0x00, 0x00, 0x80);
$f['u'] = imagecolorallocate($image, 0x00, 0x00, 0x50);
$f['l']      = imagecolorallocate($image, 0xFF, 0x00, 0x00);
$f['r']  = imagecolorallocate($image, 0x90, 0x00, 0x00);
$trans = 	imagecolorallocate($image, 254, 254, 254);


imagefill($image, 0, 0, $darkgray);

/*
imagefilledarc ( resource image, int cx, int cy, int w, int h, int s, int e, int color, int style)
*/

//Bogen oben
$s = 2*-26.57;
imagefilledarc($image, 0, 0, 85, 35, $s, $s + 180, $f['o'], IMG_ARC_PIE);

//Bogen links
$s = $s + 90;
imagefilledarc($image, 70, 0, 85, 35, $s, $s + 180, $f['l'], IMG_ARC_PIE);

//Bogen rechts
$s = $s + 90;
imagefilledarc($image, 70, 35, 85, 35, $s, $s + 180, $f['r'], IMG_ARC_PIE);

//Bogen unten
$s = $s + 90;
imagefilledarc($image, 0, 35, 85, 35, $s, $s + 180, $f['u'], IMG_ARC_PIE);


$trans = imagecolortransparent($image, $trans);

//Ecke links oben
imagefilledpolygon ($image, array("0", "17.5", "0", "0", "35", "0", "0", "17.5"), 4, $trans);

//Ecke rechts oben
imagefilledpolygon ($image, array("35", "0", "70", "0", "70", "17.5", "35", "0"), 4, $trans);

//Ecke rechts unten
imagefilledpolygon ($image, array("70", "17.5", "70", "35", "35", "35", "70", "17.5"), 4, $trans);

//Ecke links unten
imagefilledpolygon ($image, array("35", "35", "0", "17", "0", "35", "35", "35"), 4, $trans);


// flush image
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);
?> 