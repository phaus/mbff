# MySQL-Front Dump 2.5
#
# Host: imotep   Database: mbff_level2
# --------------------------------------------------------
# Server version 4.0.18-nt


#
# Table structure for table 'avatar_index'
#

DROP TABLE IF EXISTS `avatar_index`;
CREATE TABLE `avatar_index` (
  `avatar_id` int(15) unsigned default '0',
  `user_id` int(15) unsigned default NULL,
  `avatar_name` varchar(100) default NULL,
  `location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'avatar_link'
#

DROP TABLE IF EXISTS `avatar_link`;
CREATE TABLE `avatar_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `avatar_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Table structure for table 'star_index'
#

DROP TABLE IF EXISTS `star_index`;
CREATE TABLE `star_index` (
  `star_id` int(15) unsigned default '0',
  `star_system_id` int(15) unsigned default '0',
  `star_typ` int(2) unsigned default '0',
  `star_name` varchar(100) default NULL,
  `star_location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'star_link'
#

DROP TABLE IF EXISTS `star_link`;
CREATE TABLE `star_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `star_id` int(15) unsigned default '0'
) TYPE=MyISAM;

