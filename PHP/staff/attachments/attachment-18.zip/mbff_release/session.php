<?php
	@extract($_REQUEST);
	@extract($_POST);

	if($HTTP_COOKIE_VARS[$sys_conf['string']])
		$sid = $HTTP_COOKIE_VARS[$sys_conf['string']];
	$hp['user'] = "Gast";
	$sys_conf['lang'] = "de";
	
	if($user_id)
		$sid = getnewsid();		
	elseif($user_id = is_sid_activ($sid)){
		$c_user = new c_user($user_id);
		$c_user->get_data();
		$user = $c_user->return_data_array();
		update_session($sid, $user_id);
		$hp['user'] = $user['username'];
		
	}elseif($sid){
		$user_id = -2;
	}else{
		$user_id = -1;
		$sid = getnewsid();
	}
	$hp[title] = $hp['user']."@";
//Spracheeinstellungen
	if($user_id > 0){
		if($s_lang){
			set_session_var("lang", $s_lang);
			$sys_conf['lang'] = $s_lang;
			$c_user->set_entry("lang", $s_lang);
			$c_user->save_data();
		}else{
			if($user['lang'])
				$sys_conf['lang'] =  $user['lang'];
			else{
				if($lang = get_session_var("lang"))
					$sys_conf['lang'] = $lang;
				$c_user->set_entry("lang", $sys_conf['lang']);
				$c_user->save_data();
			}
		}
	}else{
		if($s_lang){
			if($sid)
				set_session_var("lang", $s_lang);
		}
	}
require("./include/onstartup.php");
?>