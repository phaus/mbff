
           ========================================
             Information-File for MySQL-Front 2.5
           ========================================


--------------------------------------
 General:
--------------------------------------
MySQL-Front is an easy-to-use-interface for web-workers dealing with
MySQL-Databases. It requires libmySQL.dll from the MySQL-Server as
"API" (included in this package - newest version available at
http://www.mysql.com/).



--------------------------------------
 (Easy) Installation:
--------------------------------------
Just doubleclick the setup-file and follow the instructions.



--------------------------------------
 With MySQL-Front you can...
--------------------------------------
- create/drop databases 
- create/drop tables 
- edit/add/delete fields 
- edit/insert/delete records 
- edit BLOBs with Bitmap/GIF/JPEG-Support 
- a list of server-variables 
- view and kill other user-processes 
- execute (large) SQL-scripts 
- view advanced table-properties, such as Type, Comment, Key_Length
  and so on 
- export table-structure and data into SQL-scripts or other databases 
- replicate databases between two hosts ("Export tables...")
- save data to CSV-Files (ideal for working with MS-Excel) or
  HTML-tables 
- copy CSV-data/HTML-Tables to clipboard 
- copy tables to new table-names
- change table-types to ISAM, MYISAM, MERGE, HEAP, InnoDB, BDB or
  userdefined types
- manage users (New in 2.0: edit existing users!)
- flush Host/Logs/Privileges/Tables 
- write SQL-queries with syntax-highlighting 
- import data from ODBC-datasources
- do table-diagnostics (check, optimize, repair, analyze)
- insert files into BLOBs in batch-mode
- and a lot more... 



--------------------------------------
Changes to the last version:
--------------------------------------

Many many many new features, improvements and bugfixes in version 2.5. Most of
them concern the data-grids.

See the complete changes-log on http://my.anse.de/changes.php



--------------------------------------
 Requirements:
--------------------------------------
- libmysql.dll (Client-library for MySQL-Server) 
- msvcrt.dll (Microsoft (R) C Runtime Library) 
- TCP/IP-Protocol 
- ODBC-Engine (for the ODBC-import-option) 

In case ODBC makes problems, you need to go to the Microsoft site,
download and install DCOM95 from
http://www.microsoft.com/com/dcom/dcom95/download.asp and then
download and install MDAC 2.6.RTM from
http://www.microsoft.com/data/download_260rtm.htm
Note: DCOM95 is only needed for Windows 95 - it is not needed for
later Windows versions.



--------------------------------------
 Troubleshooting:
--------------------------------------
I have set up a FAQ with some questions which were asked very often:
 http://www.anse.de/mysqlfront/faq.php

In case there is no answer to your question found in the FAQ, you can
post in the Support-Forum:
 http://mysqlfront.venturemedia.de/
Thanks to Jan Schmitz-Reinthal for setting up this proper forum!


Please do *not* send me e-mails with technical questions. I get so many
mails each day, I cannot reply to them all. Instead you should at first
have a look at the forum (URL above).



--------------------------------------
 Donation:
--------------------------------------
MySQL-Front is Freeware.

Maybe it saved you a lot of time and therefore you like it. In this case
you may make a donation. For this purpose point your web-browser
to the following URL:

 https://order.kagi.com/?G4T



--------------------------------------
 The Author:
--------------------------------------
 Ansgar Becker
 48485 Neuenkirchen / Germany


--------------------------------------
 Project-Homepage
--------------------------------------
http://www.mysqlfront.de/
 or
http://my.anse.de/


EOF