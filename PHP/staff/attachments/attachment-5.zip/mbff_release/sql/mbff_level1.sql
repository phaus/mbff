# MySQL-Front Dump 2.5
#
# Host: imotep   Database: mbff_level1
# --------------------------------------------------------
# Server version 4.0.18-nt


#
# Table structure for table 'sessions'
#

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `sid` varchar(32) default '0',
  `user_id` int(15) unsigned default '0',
  `session_start` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'sessions'
#

INSERT INTO `sessions` (`sid`, `user_id`, `session_start`) VALUES("6bbeff67e63965b1b5c9a31101573b59", "1", "1106781941");


#
# Table structure for table 'sessions_value'
#

DROP TABLE IF EXISTS `sessions_value`;
CREATE TABLE `sessions_value` (
  `sid` varchar(32) default '0',
  `session_value_name` varchar(50) default '0',
  `session_value` text
) TYPE=MyISAM;



#
# Dumping data for table 'sessions_value'
#



#
# Table structure for table 'systems_index'
#

DROP TABLE IF EXISTS `systems_index`;
CREATE TABLE `systems_index` (
  `system_id` int(15) unsigned default '0',
  `system_name` varchar(100) default NULL,
  `system_location` varchar(40) default 'a:3:{i:0;i:0000;i:1;i:0000;i:2;i:0000;}',
  `date` int(15) unsigned default '0',
  `activ` varchar(10) default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'systems_index'
#

INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("1", "Solde", "a:3:{i:0;i:180;i:1;i:66;i:2;i:0;}", "1106602205", "35B5EE2637");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("2", "Nabuba", "a:3:{i:0;i:544;i:1;i:252;i:2;i:0;}", "1106602206", "84C6D17A64");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("3", "Soioneschratauri", "a:3:{i:0;i:544;i:1;i:181;i:2;i:0;}", "1106602207", "19CFFE29B8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("4", "Al", "a:3:{i:0;i:495;i:1;i:612;i:2;i:0;}", "1106602208", "8305273883");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("5", "Rophabura", "a:3:{i:0;i:425;i:1;i:94;i:2;i:0;}", "1106602208", "680BE11BCC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("6", "Kabueschstauri", "a:3:{i:0;i:256;i:1;i:371;i:2;i:0;}", "1106602210", "2855776BEE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("7", "Robubaratauri", "a:3:{i:0;i:265;i:1;i:165;i:2;i:0;}", "1106602211", "28904372E0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("8", "Kamueschs", "a:3:{i:0;i:197;i:1;i:784;i:2;i:0;}", "1106602212", "B61D1FDE12");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("9", "Albu", "a:3:{i:0;i:803;i:1;i:596;i:2;i:0;}", "1106602213", "3727D6FCB1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("10", "Solmuesch Centauri", "a:3:{i:0;i:206;i:1;i:157;i:2;i:0;}", "1106602213", "F3307088A4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("11", "Solmu", "a:3:{i:0;i:175;i:1;i:444;i:2;i:0;}", "1106602214", "B3B1A11AA2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("12", "Soionlusanri", "a:3:{i:0;i:284;i:1;i:742;i:2;i:0;}", "1106602214", "C7D34E0E26");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("13", "Kaphabu Cen", "a:3:{i:0;i:303;i:1;i:129;i:2;i:0;}", "1106602214", "0DB5E10C99");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("14", "Somuesch Cen", "a:3:{i:0;i:258;i:1;i:580;i:2;i:0;}", "1106602215", "91E50666BA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("15", "Kaionesch", "a:3:{i:0;i:873;i:1;i:384;i:2;i:0;}", "1106602215", "9B84A15808");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("16", "Romeba Centauri", "a:3:{i:0;i:483;i:1;i:657;i:2;i:0;}", "1106602215", "56625784BC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("17", "Sode", "a:3:{i:0;i:712;i:1;i:460;i:2;i:0;}", "1106602215", "07167FA890");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("18", "Ropha", "a:3:{i:0;i:710;i:1;i:649;i:2;i:0;}", "1106602215", "83CD1B64F2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("19", "Nadebaraanri", "a:3:{i:0;i:109;i:1;i:731;i:2;i:0;}", "1106602215", "718FF9DF59");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("20", "Solmubasan", "a:3:{i:0;i:505;i:1;i:625;i:2;i:0;}", "1106602216", "CCCF5525D9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("21", "Sol", "a:3:{i:0;i:813;i:1;i:636;i:2;i:0;}", "1106602216", "36A8124854");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("22", "Somelura", "a:3:{i:0;i:707;i:1;i:319;i:2;i:0;}", "1106602216", "F4EA8D4C65");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("23", "Or", "a:3:{i:0;i:338;i:1;i:162;i:2;i:0;}", "1106602216", "4C3D8ABF6B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("24", "Solion", "a:3:{i:0;i:598;i:1;i:545;i:2;i:0;}", "1106602216", "FA62A91EE6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("25", "Na", "a:3:{i:0;i:776;i:1;i:367;i:2;i:0;}", "1106602217", "24AD0138DF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("26", "Ka", "a:3:{i:0;i:416;i:1;i:272;i:2;i:0;}", "1106602217", "99541622E2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("27", "Solmuluratauri", "a:3:{i:0;i:710;i:1;i:322;i:2;i:0;}", "1106602217", "513BAF0182");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("28", "Soionlu", "a:3:{i:0;i:803;i:1;i:448;i:2;i:0;}", "1106602217", "4C903AD44B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("29", "Solmebasan", "a:3:{i:0;i:346;i:1;i:332;i:2;i:0;}", "1106602217", "12EA0C2396");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("30", "Rophabustau", "a:3:{i:0;i:452;i:1;i:502;i:2;i:0;}", "1106602218", "F41D9EE1C9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("31", "Namulu", "a:3:{i:0;i:290;i:1;i:386;i:2;i:0;}", "1106602218", "E148FAFC1B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("32", "Some", "a:3:{i:0;i:729;i:1;i:680;i:2;i:0;}", "1106602218", "E0047F749B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("33", "Albueschstau", "a:3:{i:0;i:709;i:1;i:457;i:2;i:0;}", "1106602218", "2E603E4093");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("34", "Alphaeschraanri", "a:3:{i:0;i:642;i:1;i:443;i:2;i:0;}", "1106602218", "E9ECE65DE5");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("35", "Albuburaanri", "a:3:{i:0;i:401;i:1;i:369;i:2;i:0;}", "1106602219", "D05EE84088");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("36", "Solbueschraanri", "a:3:{i:0;i:791;i:1;i:396;i:2;i:0;}", "1106602219", "07C7DEAFE4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("37", "Orbulu", "a:3:{i:0;i:857;i:1;i:512;i:2;i:0;}", "1106602219", "DCC55095B3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("38", "Robulu Cenanri", "a:3:{i:0;i:872;i:1;i:420;i:2;i:0;}", "1106602219", "DB738901C9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("39", "Solmebu", "a:3:{i:0;i:551;i:1;i:388;i:2;i:0;}", "1106602219", "DC43B8A53F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("40", "Ormubu", "a:3:{i:0;i:218;i:1;i:129;i:2;i:0;}", "1106602220", "10FEF2BAEF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("41", "Naphabu Cen", "a:3:{i:0;i:777;i:1;i:57;i:2;i:0;}", "1106602220", "57F088EFE7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("42", "Aldeluratauri", "a:3:{i:0;i:678;i:1;i:171;i:2;i:0;}", "1106602220", "69213D2F36");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("43", "Name", "a:3:{i:0;i:696;i:1;i:485;i:2;i:0;}", "1106602220", "C9D455AB32");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("44", "Ormubu Cen", "a:3:{i:0;i:440;i:1;i:127;i:2;i:0;}", "1106602220", "265B4F14DE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("45", "Kamelustau", "a:3:{i:0;i:602;i:1;i:122;i:2;i:0;}", "1106602221", "693B3E478C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("46", "Orpha", "a:3:{i:0;i:765;i:1;i:408;i:2;i:0;}", "1106602221", "54DD007230");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("47", "Namu", "a:3:{i:0;i:670;i:1;i:448;i:2;i:0;}", "1106602221", "81BE564A27");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("48", "Kabuba", "a:3:{i:0;i:107;i:1;i:773;i:2;i:0;}", "1106602221", "BD871185A0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("49", "Roionbasanri", "a:3:{i:0;i:329;i:1;i:614;i:2;i:0;}", "1106602221", "CCADE9D26D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("50", "Namebastau", "a:3:{i:0;i:299;i:1;i:655;i:2;i:0;}", "1106602222", "F72D8FBD4C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("51", "Kame", "a:3:{i:0;i:477;i:1;i:221;i:2;i:0;}", "1106602222", "4657DED2DA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("52", "Kabubastauri", "a:3:{i:0;i:440;i:1;i:700;i:2;i:0;}", "1106602222", "C486558EEA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("53", "So", "a:3:{i:0;i:536;i:1;i:480;i:2;i:0;}", "1106602222", "5D21A76FF6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("54", "Alphaluraanri", "a:3:{i:0;i:659;i:1;i:669;i:2;i:0;}", "1106602222", "8D5F46DB61");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("55", "Roionlu Cen", "a:3:{i:0;i:155;i:1;i:445;i:2;i:0;}", "1106602223", "B5093A9217");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("56", "Alde", "a:3:{i:0;i:298;i:1;i:485;i:2;i:0;}", "1106602223", "09BB0C9BC6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("57", "Alphabu", "a:3:{i:0;i:546;i:1;i:417;i:2;i:0;}", "1106602223", "FAF366607E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("58", "Alionlusanri", "a:3:{i:0;i:315;i:1;i:679;i:2;i:0;}", "1106602223", "7E26643A34");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("59", "Albubasanri", "a:3:{i:0;i:143;i:1;i:670;i:2;i:0;}", "1106602223", "31643A0EF6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("60", "Somebu Cenanri", "a:3:{i:0;i:303;i:1;i:505;i:2;i:0;}", "1106602224", "202B14B8A6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("61", "Sodeeschs", "a:3:{i:0;i:418;i:1;i:514;i:2;i:0;}", "1106602224", "3877286411");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("62", "Aldelu Cen", "a:3:{i:0;i:607;i:1;i:590;i:2;i:0;}", "1106602224", "1F6AE798B9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("63", "Kaioneschs", "a:3:{i:0;i:277;i:1;i:240;i:2;i:0;}", "1106602224", "5493413895");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("64", "Robueschs", "a:3:{i:0;i:464;i:1;i:577;i:2;i:0;}", "1106602224", "86A0C5CADF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("65", "Solmeeschs", "a:3:{i:0;i:685;i:1;i:307;i:2;i:0;}", "1106602225", "E667B98B00");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("66", "Kaphabustauri", "a:3:{i:0;i:741;i:1;i:433;i:2;i:0;}", "1106602225", "568622F5A1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("67", "Kamubara", "a:3:{i:0;i:109;i:1;i:458;i:2;i:0;}", "1106602225", "46E75E9052");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("68", "Somulu", "a:3:{i:0;i:321;i:1;i:318;i:2;i:0;}", "1106602225", "FBF8230295");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("69", "Soldeeschs", "a:3:{i:0;i:915;i:1;i:700;i:2;i:0;}", "1106602225", "CBC9DC1F1C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("70", "Solbu", "a:3:{i:0;i:654;i:1;i:720;i:2;i:0;}", "1106602226", "F53C4D59D2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("71", "Solmuluraanri", "a:3:{i:0;i:463;i:1;i:631;i:2;i:0;}", "1106602226", "38380D68DC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("72", "Napha", "a:3:{i:0;i:840;i:1;i:494;i:2;i:0;}", "1106602226", "1F9DA44FB4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("73", "Rophaluraanri", "a:3:{i:0;i:179;i:1;i:824;i:2;i:0;}", "1106602226", "64A9A5BBE6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("74", "Alion", "a:3:{i:0;i:498;i:1;i:718;i:2;i:0;}", "1106602226", "7436DCE190");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("75", "Solbuba", "a:3:{i:0;i:384;i:1;i:727;i:2;i:0;}", "1106602227", "C3DC6C541C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("76", "Robuluraanri", "a:3:{i:0;i:875;i:1;i:298;i:2;i:0;}", "1106602227", "39AD2323E5");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("77", "Ormuesch", "a:3:{i:0;i:267;i:1;i:423;i:2;i:0;}", "1106602227", "6853D1E45F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("78", "Orme", "a:3:{i:0;i:848;i:1;i:620;i:2;i:0;}", "1106602227", "E916FE5BCE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("79", "Kamubu", "a:3:{i:0;i:745;i:1;i:381;i:2;i:0;}", "1106602228", "8AC77A1916");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("80", "Orion", "a:3:{i:0;i:797;i:1;i:482;i:2;i:0;}", "1106602228", "F66F98AE90");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("81", "Soldeburatauri", "a:3:{i:0;i:800;i:1;i:665;i:2;i:0;}", "1106602228", "AB554EF7F5");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("82", "Naion", "a:3:{i:0;i:545;i:1;i:798;i:2;i:0;}", "1106602228", "916421EE05");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("83", "Rodelu Centau", "a:3:{i:0;i:657;i:1;i:329;i:2;i:0;}", "1106602228", "4037D80E72");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("84", "Alphabasanri", "a:3:{i:0;i:458;i:1;i:114;i:2;i:0;}", "1106602228", "53C9EA5A3C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("85", "Nameba Centau", "a:3:{i:0;i:691;i:1;i:290;i:2;i:0;}", "1106602229", "E9A9677408");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("86", "Sophaburaan", "a:3:{i:0;i:647;i:1;i:92;i:2;i:0;}", "1106602229", "0757B8DDB9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("87", "Rophabaratauri", "a:3:{i:0;i:236;i:1;i:192;i:2;i:0;}", "1106602229", "B12DC63A46");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("88", "Solmuesch Cenan", "a:3:{i:0;i:921;i:1;i:388;i:2;i:0;}", "1106602229", "341A9317AD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("89", "Solionburatauri", "a:3:{i:0;i:302;i:1;i:631;i:2;i:0;}", "1106602229", "16BB334383");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("90", "Almuburatauri", "a:3:{i:0;i:174;i:1;i:181;i:2;i:0;}", "1106602230", "73EC4C0B67");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("91", "Sophaeschs", "a:3:{i:0;i:283;i:1;i:501;i:2;i:0;}", "1106602230", "3F0E3DBFE0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("92", "Ordebura", "a:3:{i:0;i:630;i:1;i:243;i:2;i:0;}", "1106602230", "33828C5F50");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("93", "Almueschra", "a:3:{i:0;i:544;i:1;i:508;i:2;i:0;}", "1106602230", "5F556F793B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("94", "Rome", "a:3:{i:0;i:780;i:1;i:741;i:2;i:0;}", "1106602231", "7E7DCC7497");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("95", "Solionbustauri", "a:3:{i:0;i:739;i:1;i:268;i:2;i:0;}", "1106602231", "21A17DDB99");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("96", "Orbubu", "a:3:{i:0;i:189;i:1;i:438;i:2;i:0;}", "1106602231", "A0C0E4C4C7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("97", "Almuluratauri", "a:3:{i:0;i:306;i:1;i:208;i:2;i:0;}", "1106602231", "CC3AF03514");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("98", "Ormu", "a:3:{i:0;i:372;i:1;i:123;i:2;i:0;}", "1106602231", "0F7EB42534");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("99", "Kamu", "a:3:{i:0;i:147;i:1;i:193;i:2;i:0;}", "1106602232", "C8E61C8EB8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("100", "Orionbu", "a:3:{i:0;i:257;i:1;i:814;i:2;i:0;}", "1106602232", "300278A527");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("101", "Kadebura", "a:3:{i:0;i:505;i:1;i:347;i:2;i:0;}", "1106602232", "ECB764B6CB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("102", "Solphalu Centauri", "a:3:{i:0;i:528;i:1;i:305;i:2;i:0;}", "1106602232", "0B16D6E89E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("103", "Ro", "a:3:{i:0;i:589;i:1;i:325;i:2;i:0;}", "1106602264", "62F9153438");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("104", "Albuba", "a:3:{i:0;i:283;i:1;i:130;i:2;i:0;}", "1106602264", "D81DE2BFCC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("105", "Alioneschraanri", "a:3:{i:0;i:161;i:1;i:433;i:2;i:0;}", "1106602265", "7C23759711");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("106", "Ormuburatau", "a:3:{i:0;i:466;i:1;i:388;i:2;i:0;}", "1106602265", "47C784F879");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("107", "Kabubu", "a:3:{i:0;i:913;i:1;i:616;i:2;i:0;}", "1106602265", "6E9DE4357F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("108", "Kaphaeschraanri", "a:3:{i:0;i:417;i:1;i:344;i:2;i:0;}", "1106602265", "4DD8C5F56D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("109", "Kadelu", "a:3:{i:0;i:481;i:1;i:421;i:2;i:0;}", "1106602265", "215F9570AC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("110", "Solpha", "a:3:{i:0;i:630;i:1;i:619;i:2;i:0;}", "1106602266", "602B4E1BF7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("111", "Kamulu Centau", "a:3:{i:0;i:844;i:1;i:164;i:2;i:0;}", "1106602266", "A53DD08458");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("112", "Solionlu Cen", "a:3:{i:0;i:463;i:1;i:461;i:2;i:0;}", "1106602266", "3F5DD2113B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("113", "Soldelu", "a:3:{i:0;i:836;i:1;i:392;i:2;i:0;}", "1106602267", "58F65BCF3F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("114", "Nabulu", "a:3:{i:0;i:595;i:1;i:390;i:2;i:0;}", "1106602267", "0FA91F9BB7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("115", "Solmebu Cenan", "a:3:{i:0;i:763;i:1;i:95;i:2;i:0;}", "1106602267", "DC1D6D80ED");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("116", "Soldebaraanri", "a:3:{i:0;i:677;i:1;i:732;i:2;i:0;}", "1106602267", "E1F629A033");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("117", "Orbueschsanri", "a:3:{i:0;i:592;i:1;i:355;i:2;i:0;}", "1106602267", "C8531FE507");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("118", "Almuburaanri", "a:3:{i:0;i:882;i:1;i:379;i:2;i:0;}", "1106602268", "0E722564ED");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("119", "Romulu", "a:3:{i:0;i:838;i:1;i:432;i:2;i:0;}", "1106602268", "D3ADEB05FC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("120", "Somu", "a:3:{i:0;i:355;i:1;i:552;i:2;i:0;}", "1106602268", "DD398FF763");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("121", "Nadebastauri", "a:3:{i:0;i:302;i:1;i:156;i:2;i:0;}", "1106602268", "0F49D42CDE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("122", "Kamuluratauri", "a:3:{i:0;i:897;i:1;i:789;i:2;i:0;}", "1106602269", "F65F3339A8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("123", "Soionba", "a:3:{i:0;i:478;i:1;i:615;i:2;i:0;}", "1106602269", "C3A51EFAB9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("124", "Albuesch Cen", "a:3:{i:0;i:195;i:1;i:345;i:2;i:0;}", "1106602269", "8A25574086");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("125", "Almubu", "a:3:{i:0;i:488;i:1;i:476;i:2;i:0;}", "1106602269", "E4A1F3DF6B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("126", "Kameeschsanri", "a:3:{i:0;i:465;i:1;i:769;i:2;i:0;}", "1106602269", "191EE2EECB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("127", "Orbubaraan", "a:3:{i:0;i:223;i:1;i:400;i:2;i:0;}", "1106602270", "EB7B4E6FAD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("128", "Somuba Centau", "a:3:{i:0;i:513;i:1;i:724;i:2;i:0;}", "1106602270", "735ADB1691");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("129", "Ordelu", "a:3:{i:0;i:229;i:1;i:437;i:2;i:0;}", "1106602270", "C3481A4252");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("130", "Kapha", "a:3:{i:0;i:670;i:1;i:776;i:2;i:0;}", "1106602271", "A50782D55E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("131", "Nadelu", "a:3:{i:0;i:418;i:1;i:710;i:2;i:0;}", "1106602271", "75CEFC8635");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("132", "Kabulus", "a:3:{i:0;i:772;i:1;i:763;i:2;i:0;}", "1106602271", "FDEABE42D7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("133", "Kamubasan", "a:3:{i:0;i:551;i:1;i:710;i:2;i:0;}", "1106602272", "3D7164EA71");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("134", "Ormulu Cenanri", "a:3:{i:0;i:870;i:1;i:331;i:2;i:0;}", "1106602272", "64A09066E0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("135", "Ordelura", "a:3:{i:0;i:709;i:1;i:757;i:2;i:0;}", "1106602272", "26DA9ACCA0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("136", "Solphabastau", "a:3:{i:0;i:675;i:1;i:468;i:2;i:0;}", "1106602273", "510D52C15F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("137", "Romebaratau", "a:3:{i:0;i:840;i:1;i:489;i:2;i:0;}", "1106602273", "09A5324289");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("138", "Soldeba Centau", "a:3:{i:0;i:855;i:1;i:374;i:2;i:0;}", "1106602274", "5F85C68ABB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("139", "Rophalu", "a:3:{i:0;i:475;i:1;i:733;i:2;i:0;}", "1106602274", "039357A55F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("140", "Kamulus", "a:3:{i:0;i:708;i:1;i:112;i:2;i:0;}", "1106602275", "C04D9AB495");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("141", "Orbuburatau", "a:3:{i:0;i:453;i:1;i:470;i:2;i:0;}", "1106602275", "25CCDC47EE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("142", "Kaphaesch Cen", "a:3:{i:0;i:862;i:1;i:282;i:2;i:0;}", "1106602276", "C94B5A20E0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("143", "Kamueschra", "a:3:{i:0;i:256;i:1;i:120;i:2;i:0;}", "1106602277", "677AD3FD6F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("144", "Kaionluratauri", "a:3:{i:0;i:465;i:1;i:594;i:2;i:0;}", "1106602277", "6578730BDA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("145", "Kaionbaraan", "a:3:{i:0;i:717;i:1;i:529;i:2;i:0;}", "1106602278", "17C5B51D7A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("146", "Roionlustau", "a:3:{i:0;i:628;i:1;i:361;i:2;i:0;}", "1106602278", "69FF775C44");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("147", "Naphabura", "a:3:{i:0;i:845;i:1;i:509;i:2;i:0;}", "1106602278", "7174A1D3D7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("148", "Solioneschs", "a:3:{i:0;i:109;i:1;i:82;i:2;i:0;}", "1106602279", "367F282754");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("149", "Kaion", "a:3:{i:0;i:315;i:1;i:352;i:2;i:0;}", "1106602279", "DAB35DB1DC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("150", "Solphabaraan", "a:3:{i:0;i:566;i:1;i:591;i:2;i:0;}", "1106602279", "BDD17595F4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("151", "Romeesch Centauri", "a:3:{i:0;i:736;i:1;i:740;i:2;i:0;}", "1106602280", "A68C808858");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("152", "Ordeba", "a:3:{i:0;i:296;i:1;i:271;i:2;i:0;}", "1106602280", "3DE1AE0D0F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("153", "Nade", "a:3:{i:0;i:695;i:1;i:643;i:2;i:0;}", "1106602281", "826569B7EF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("154", "Naphalustauri", "a:3:{i:0;i:283;i:1;i:654;i:2;i:0;}", "1106602281", "757AE23DAE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("155", "Orionlu Centauri", "a:3:{i:0;i:546;i:1;i:619;i:2;i:0;}", "1106602281", "A887FC7548");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("156", "Albuesch Cenan", "a:3:{i:0;i:288;i:1;i:647;i:2;i:0;}", "1106602282", "78C0AD0896");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("157", "Naphaesch Cen", "a:3:{i:0;i:385;i:1;i:668;i:2;i:0;}", "1106602282", "58B7DA1FFC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("158", "Romelusan", "a:3:{i:0;i:678;i:1;i:547;i:2;i:0;}", "1106602282", "B7428F3C1E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("159", "Somubu", "a:3:{i:0;i:587;i:1;i:291;i:2;i:0;}", "1106602282", "0A03EF0A15");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("160", "Sopha", "a:3:{i:0;i:398;i:1;i:765;i:2;i:0;}", "1106602282", "252708C346");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("161", "Solbuesch", "a:3:{i:0;i:621;i:1;i:153;i:2;i:0;}", "1106602283", "8A28159FDE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("162", "Orionbaratau", "a:3:{i:0;i:904;i:1;i:593;i:2;i:0;}", "1106602283", "1057260F92");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("163", "Nameluratauri", "a:3:{i:0;i:328;i:1;i:50;i:2;i:0;}", "1106602283", "9595D94F31");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("164", "Someesch", "a:3:{i:0;i:410;i:1;i:611;i:2;i:0;}", "1106602283", "9C78F3D2D0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("165", "Solionbu", "a:3:{i:0;i:119;i:1;i:68;i:2;i:0;}", "1106602283", "6598F581B3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("166", "Kamuesch", "a:3:{i:0;i:814;i:1;i:676;i:2;i:0;}", "1106602284", "AB0701E107");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("167", "Soldeba", "a:3:{i:0;i:384;i:1;i:198;i:2;i:0;}", "1106602284", "10BAAA8758");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("168", "Solmulu Centau", "a:3:{i:0;i:746;i:1;i:99;i:2;i:0;}", "1106602284", "465DBF7B95");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("169", "Nabuba Cen", "a:3:{i:0;i:433;i:1;i:471;i:2;i:0;}", "1106602284", "2ADC99A644");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("170", "Somelu Cenanri", "a:3:{i:0;i:240;i:1;i:369;i:2;i:0;}", "1106602284", "6925DF30E3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("171", "Solmeeschratauri", "a:3:{i:0;i:200;i:1;i:715;i:2;i:0;}", "1106602285", "700C92124C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("172", "Ordebasan", "a:3:{i:0;i:805;i:1;i:358;i:2;i:0;}", "1106602285", "5319B78283");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("173", "Orphaba Cen", "a:3:{i:0;i:721;i:1;i:330;i:2;i:0;}", "1106602285", "745C0B9A2D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("174", "Sophalusan", "a:3:{i:0;i:663;i:1;i:694;i:2;i:0;}", "1106602285", "2B5151FA78");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("175", "Nadeesch Cen", "a:3:{i:0;i:794;i:1;i:376;i:2;i:0;}", "1106602285", "15EC94A19F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("176", "Kadebaratauri", "a:3:{i:0;i:814;i:1;i:376;i:2;i:0;}", "1106602286", "CA48CFFF12");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("177", "Aldeeschratau", "a:3:{i:0;i:829;i:1;i:82;i:2;i:0;}", "1106602286", "4830EF8392");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("178", "Solphalu", "a:3:{i:0;i:433;i:1;i:820;i:2;i:0;}", "1106602286", "2F94E82E23");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("179", "Someeschstau", "a:3:{i:0;i:501;i:1;i:546;i:2;i:0;}", "1106602286", "645E4BACF2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("180", "Solionbaraan", "a:3:{i:0;i:915;i:1;i:203;i:2;i:0;}", "1106602286", "C3F7DA7C4E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("181", "Almeluraanri", "a:3:{i:0;i:884;i:1;i:517;i:2;i:0;}", "1106602287", "470B5105D4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("182", "Sobu", "a:3:{i:0;i:878;i:1;i:682;i:2;i:0;}", "1106602287", "B0A4F7EDEB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("183", "Kaphalu", "a:3:{i:0;i:353;i:1;i:544;i:2;i:0;}", "1106602287", "99355766F9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("184", "Orbueschratauri", "a:3:{i:0;i:260;i:1;i:172;i:2;i:0;}", "1106602287", "A3702E6BB2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("185", "Sophaesch", "a:3:{i:0;i:400;i:1;i:674;i:2;i:0;}", "1106602287", "C5288A5C40");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("186", "Ordeesch", "a:3:{i:0;i:139;i:1;i:547;i:2;i:0;}", "1106602288", "B822B5654C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("187", "Rophaburaanri", "a:3:{i:0;i:311;i:1;i:76;i:2;i:0;}", "1106602288", "D90E35EFD4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("188", "Ormuluratauri", "a:3:{i:0;i:739;i:1;i:819;i:2;i:0;}", "1106602288", "6A50034A66");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("189", "Nabuburatauri", "a:3:{i:0;i:920;i:1;i:245;i:2;i:0;}", "1106602288", "A155646DE4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("190", "Kamebu", "a:3:{i:0;i:470;i:1;i:113;i:2;i:0;}", "1106602288", "9130C2202E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("191", "Alphabus", "a:3:{i:0;i:226;i:1;i:528;i:2;i:0;}", "1106602289", "0E1D67FD65");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("192", "Somuesch", "a:3:{i:0;i:529;i:1;i:797;i:2;i:0;}", "1106602289", "43053B19EF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("193", "Orphaesch Centau", "a:3:{i:0;i:481;i:1;i:269;i:2;i:0;}", "1106602289", "B8A8DFD94B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("194", "Nameesch Cen", "a:3:{i:0;i:250;i:1;i:333;i:2;i:0;}", "1106602289", "2396C29C6D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("195", "Solphaesch", "a:3:{i:0;i:315;i:1;i:755;i:2;i:0;}", "1106602290", "473D3FB27B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("196", "Nabu", "a:3:{i:0;i:635;i:1;i:115;i:2;i:0;}", "1106602290", "C377C551C3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("197", "Ordeburatauri", "a:3:{i:0;i:843;i:1;i:98;i:2;i:0;}", "1106602290", "5F28BD788F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("198", "Kaionbu", "a:3:{i:0;i:706;i:1;i:225;i:2;i:0;}", "1106602290", "CD6B8EC61B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("199", "Almebara", "a:3:{i:0;i:778;i:1;i:626;i:2;i:0;}", "1106602290", "E02D673B76");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("200", "Solmeeschratau", "a:3:{i:0;i:452;i:1;i:699;i:2;i:0;}", "1106602291", "44B1897A18");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("201", "Orbuburaan", "a:3:{i:0;i:481;i:1;i:645;i:2;i:0;}", "1106602291", "B3183CDD96");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("202", "Almeeschsan", "a:3:{i:0;i:658;i:1;i:270;i:2;i:0;}", "1106602291", "456BE2E88A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("203", "Almubas", "a:3:{i:0;i:289;i:1;i:686;i:2;i:0;}", "1106602355", "D331F8DE0D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("204", "Almu", "a:3:{i:0;i:128;i:1;i:642;i:2;i:0;}", "1106602355", "F46B386984");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("205", "Rodeesch Cen", "a:3:{i:0;i:304;i:1;i:643;i:2;i:0;}", "1106602355", "A870284866");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("206", "Nabuba Cenan", "a:3:{i:0;i:282;i:1;i:430;i:2;i:0;}", "1106602355", "5D657E4124");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("207", "Solionbustau", "a:3:{i:0;i:228;i:1;i:791;i:2;i:0;}", "1106602356", "55D9E6BEA7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("208", "Sobulustau", "a:3:{i:0;i:761;i:1;i:759;i:2;i:0;}", "1106602356", "D0025AE60D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("209", "Alphalu", "a:3:{i:0;i:399;i:1;i:630;i:2;i:0;}", "1106602356", "81E49040F8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("210", "Romubaraanri", "a:3:{i:0;i:795;i:1;i:224;i:2;i:0;}", "1106602356", "FCCAF4F5F3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("211", "Romubus", "a:3:{i:0;i:302;i:1;i:559;i:2;i:0;}", "1106602356", "2460E7FE42");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("212", "Romebu", "a:3:{i:0;i:878;i:1;i:431;i:2;i:0;}", "1106602357", "267AB5D66C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("213", "Sodeeschra", "a:3:{i:0;i:497;i:1;i:745;i:2;i:0;}", "1106602357", "F08340BE90");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("214", "Orbubusan", "a:3:{i:0;i:365;i:1;i:467;i:2;i:0;}", "1106602357", "EADBE3BE69");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("215", "Romubas", "a:3:{i:0;i:497;i:1;i:799;i:2;i:0;}", "1106602357", "339EE93FD6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("216", "Nadeba", "a:3:{i:0;i:545;i:1;i:498;i:2;i:0;}", "1106602357", "CF8F3F65AF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("217", "Kadebusanri", "a:3:{i:0;i:494;i:1;i:540;i:2;i:0;}", "1106602358", "8D504BAB89");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("218", "Robubusan", "a:3:{i:0;i:894;i:1;i:154;i:2;i:0;}", "1106602358", "D22B5CB058");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("219", "Orbubus", "a:3:{i:0;i:309;i:1;i:565;i:2;i:0;}", "1106602358", "0883007F69");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("220", "Ordeesch Cen", "a:3:{i:0;i:738;i:1;i:403;i:2;i:0;}", "1106602358", "DD98FDD878");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("221", "Solmubasanri", "a:3:{i:0;i:243;i:1;i:372;i:2;i:0;}", "1106602358", "AE80860D0E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("222", "Aldebu Centau", "a:3:{i:0;i:826;i:1;i:603;i:2;i:0;}", "1106602358", "C4487F0D87");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("223", "Naphaesch", "a:3:{i:0;i:869;i:1;i:659;i:2;i:0;}", "1106602359", "06D0C5C340");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("224", "Soionlustau", "a:3:{i:0;i:519;i:1;i:112;i:2;i:0;}", "1106602359", "91A90359C6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("225", "Naphabu Cenanri", "a:3:{i:0;i:403;i:1;i:333;i:2;i:0;}", "1106602359", "F55E7ECF43");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("226", "Namubu", "a:3:{i:0;i:584;i:1;i:81;i:2;i:0;}", "1106602359", "E672D1D65A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("227", "Sobulu", "a:3:{i:0;i:449;i:1;i:194;i:2;i:0;}", "1106602359", "20FF393163");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("228", "Kabuesch Cenanri", "a:3:{i:0;i:497;i:1;i:619;i:2;i:0;}", "1106602360", "5168C563BF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("229", "Kamubas", "a:3:{i:0;i:756;i:1;i:161;i:2;i:0;}", "1106602360", "93AB9102A2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("230", "Albubu Cenanri", "a:3:{i:0;i:462;i:1;i:766;i:2;i:0;}", "1106602360", "9684F23C5C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("231", "Orionba Centauri", "a:3:{i:0;i:229;i:1;i:262;i:2;i:0;}", "1106602360", "80498B1E98");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("232", "Kaphaeschsanri", "a:3:{i:0;i:805;i:1;i:707;i:2;i:0;}", "1106602360", "A1B396CFAF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("233", "Solmueschs", "a:3:{i:0;i:177;i:1;i:211;i:2;i:0;}", "1106602361", "C270615A69");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("234", "Alpha", "a:3:{i:0;i:481;i:1;i:246;i:2;i:0;}", "1106602361", "1E7CB0B0D1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("235", "Kaphaeschstauri", "a:3:{i:0;i:286;i:1;i:56;i:2;i:0;}", "1106602361", "49F029E9F1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("236", "Nadebaratauri", "a:3:{i:0;i:687;i:1;i:265;i:2;i:0;}", "1106602361", "3BF04968F1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("237", "Albueschraan", "a:3:{i:0;i:720;i:1;i:236;i:2;i:0;}", "1106602361", "CEC938368B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("238", "Ormueschsan", "a:3:{i:0;i:824;i:1;i:492;i:2;i:0;}", "1106602362", "235A70AC1F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("239", "Ormueschraanri", "a:3:{i:0;i:114;i:1;i:599;i:2;i:0;}", "1106602362", "05AE84EFE8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("240", "Kabubu Cen", "a:3:{i:0;i:419;i:1;i:307;i:2;i:0;}", "1106602362", "D8C677230D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("241", "Almebaraan", "a:3:{i:0;i:701;i:1;i:102;i:2;i:0;}", "1106602362", "D232FDE221");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("242", "Orphabara", "a:3:{i:0;i:563;i:1;i:360;i:2;i:0;}", "1106602362", "8257E3516D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("243", "Albueschsan", "a:3:{i:0;i:906;i:1;i:704;i:2;i:0;}", "1106602363", "5DFB1AD288");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("244", "Solmuluraan", "a:3:{i:0;i:851;i:1;i:650;i:2;i:0;}", "1106602363", "C6CCC3F404");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("245", "Ormebaraanri", "a:3:{i:0;i:884;i:1;i:594;i:2;i:0;}", "1106602363", "546099BC9F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("246", "Albulura", "a:3:{i:0;i:767;i:1;i:344;i:2;i:0;}", "1106602364", "FE54F79E54");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("247", "Sophalu", "a:3:{i:0;i:849;i:1;i:310;i:2;i:0;}", "1106602364", "680F362924");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("248", "Alionburatauri", "a:3:{i:0;i:870;i:1;i:632;i:2;i:0;}", "1106602368", "38BEB42871");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("249", "Aldeesch", "a:3:{i:0;i:409;i:1;i:119;i:2;i:0;}", "1106602369", "38334E7667");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("250", "Somebastau", "a:3:{i:0;i:298;i:1;i:82;i:2;i:0;}", "1106602370", "60510BDA9C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("251", "Ormebastauri", "a:3:{i:0;i:566;i:1;i:121;i:2;i:0;}", "1106602371", "BE6D2B8F9F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("252", "Soionbas", "a:3:{i:0;i:889;i:1;i:314;i:2;i:0;}", "1106602371", "4A623270D3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("253", "Alme", "a:3:{i:0;i:748;i:1;i:264;i:2;i:0;}", "1106602374", "E88C2FB21E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("254", "Ormuba Centau", "a:3:{i:0;i:894;i:1;i:683;i:2;i:0;}", "1106602375", "C532D7D637");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("255", "Soldebu", "a:3:{i:0;i:345;i:1;i:244;i:2;i:0;}", "1106602375", "45ECBC7395");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("256", "Roionlu", "a:3:{i:0;i:328;i:1;i:296;i:2;i:0;}", "1106602375", "F1F63DDB83");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("257", "Orbubastauri", "a:3:{i:0;i:213;i:1;i:637;i:2;i:0;}", "1106602375", "634E7D2039");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("258", "Namuesch", "a:3:{i:0;i:495;i:1;i:607;i:2;i:0;}", "1106602375", "8D1F582C2A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("259", "Solphaeschstau", "a:3:{i:0;i:472;i:1;i:779;i:2;i:0;}", "1106602376", "D74440F902");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("260", "Kamuba", "a:3:{i:0;i:411;i:1;i:732;i:2;i:0;}", "1106602376", "7701F902E1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("261", "Orionba Cenan", "a:3:{i:0;i:285;i:1;i:366;i:2;i:0;}", "1106602376", "4E2D8DC374");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("262", "Almelustauri", "a:3:{i:0;i:499;i:1;i:408;i:2;i:0;}", "1106602376", "B250C5A4A6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("263", "Solmuesch", "a:3:{i:0;i:763;i:1;i:418;i:2;i:0;}", "1106602376", "5420A4C2E1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("264", "Kabuesch", "a:3:{i:0;i:454;i:1;i:591;i:2;i:0;}", "1106602377", "69B878398C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("265", "Almelu", "a:3:{i:0;i:124;i:1;i:115;i:2;i:0;}", "1106602377", "2DAC841F87");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("266", "Kameba Cenanri", "a:3:{i:0;i:229;i:1;i:137;i:2;i:0;}", "1106602377", "5858FE580E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("267", "Naphalus", "a:3:{i:0;i:199;i:1;i:523;i:2;i:0;}", "1106602377", "074AE5B018");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("268", "Romu", "a:3:{i:0;i:289;i:1;i:391;i:2;i:0;}", "1106602378", "1EBAF7C090");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("269", "Namubu Centauri", "a:3:{i:0;i:197;i:1;i:761;i:2;i:0;}", "1106602378", "363FF0A81C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("270", "Naionlu", "a:3:{i:0;i:426;i:1;i:111;i:2;i:0;}", "1106602378", "1B3D8DE446");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("271", "Soionesch Centauri", "a:3:{i:0;i:458;i:1;i:463;i:2;i:0;}", "1106602378", "51336D5450");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("272", "Solionesch Cenan", "a:3:{i:0;i:851;i:1;i:497;i:2;i:0;}", "1106602378", "6E92C50983");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("273", "Almelu Cenan", "a:3:{i:0;i:257;i:1;i:164;i:2;i:0;}", "1106602379", "4B383C2160");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("274", "Romebura", "a:3:{i:0;i:770;i:1;i:701;i:2;i:0;}", "1106602379", "2D69A8E918");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("275", "Kabulu", "a:3:{i:0;i:382;i:1;i:311;i:2;i:0;}", "1106602379", "BCC9B5C49A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("276", "Soionesch", "a:3:{i:0;i:292;i:1;i:143;i:2;i:0;}", "1106602379", "1E040F9F37");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("277", "Orionlu", "a:3:{i:0;i:583;i:1;i:489;i:2;i:0;}", "1106602379", "444B8D6245");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("278", "Almulu Cenanri", "a:3:{i:0;i:496;i:1;i:154;i:2;i:0;}", "1106602380", "F68611FC38");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("279", "Roionesch", "a:3:{i:0;i:643;i:1;i:766;i:2;i:0;}", "1106602380", "523EE75C59");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("280", "Rophalus", "a:3:{i:0;i:876;i:1;i:615;i:2;i:0;}", "1106602380", "7218A1A2DE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("281", "Ormebu Cenan", "a:3:{i:0;i:331;i:1;i:675;i:2;i:0;}", "1106602380", "96AA4F2266");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("282", "Orde", "a:3:{i:0;i:270;i:1;i:731;i:2;i:0;}", "1106602380", "0A53F18082");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("283", "Solphabustauri", "a:3:{i:0;i:478;i:1;i:517;i:2;i:0;}", "1106602380", "B69E35E7CA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("284", "Ordebas", "a:3:{i:0;i:875;i:1;i:822;i:2;i:0;}", "1106602381", "802B6798D3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("285", "Romubara", "a:3:{i:0;i:408;i:1;i:550;i:2;i:0;}", "1106602381", "4196C26840");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("286", "Rophabustauri", "a:3:{i:0;i:485;i:1;i:571;i:2;i:0;}", "1106602381", "6867CEA07E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("287", "Naphabu", "a:3:{i:0;i:359;i:1;i:353;i:2;i:0;}", "1106602381", "6D17761BFC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("288", "Naphabara", "a:3:{i:0;i:916;i:1;i:117;i:2;i:0;}", "1106602381", "D2B6CBB203");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("289", "Somelu Centau", "a:3:{i:0;i:355;i:1;i:431;i:2;i:0;}", "1106602382", "92B1FC8CB7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("290", "Orbulus", "a:3:{i:0;i:876;i:1;i:293;i:2;i:0;}", "1106602382", "C090725AB6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("291", "Naionbastau", "a:3:{i:0;i:285;i:1;i:738;i:2;i:0;}", "1106602382", "0F53939B4A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("292", "Nabuluraanri", "a:3:{i:0;i:549;i:1;i:622;i:2;i:0;}", "1106602382", "F544D8BB87");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("293", "Romulu Cen", "a:3:{i:0;i:488;i:1;i:705;i:2;i:0;}", "1106602382", "18E2F94154");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("294", "Rophaba Centauri", "a:3:{i:0;i:612;i:1;i:207;i:2;i:0;}", "1106602383", "2B97CF17D6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("295", "Kaphaesch", "a:3:{i:0;i:717;i:1;i:332;i:2;i:0;}", "1106602383", "1760FD45F8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("296", "Somuba Cen", "a:3:{i:0;i:601;i:1;i:651;i:2;i:0;}", "1106602383", "178B23364A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("297", "Ordebastauri", "a:3:{i:0;i:399;i:1;i:330;i:2;i:0;}", "1106602383", "1E1A76DB27");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("298", "Albubu", "a:3:{i:0;i:811;i:1;i:794;i:2;i:0;}", "1106602383", "EC4BC6E1E0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("299", "Solbubu Cenanri", "a:3:{i:0;i:528;i:1;i:480;i:2;i:0;}", "1106602384", "1446D3FACF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("300", "Kadeesch Centauri", "a:3:{i:0;i:626;i:1;i:169;i:2;i:0;}", "1106602384", "D9E1818354");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("301", "Kamelu Cen", "a:3:{i:0;i:764;i:1;i:216;i:2;i:0;}", "1106602384", "77E17804D6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("302", "Sophabusan", "a:3:{i:0;i:598;i:1;i:818;i:2;i:0;}", "1106602384", "B5999B2253");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("303", "Sophabas", "a:3:{i:0;i:382;i:1;i:284;i:2;i:0;}", "1106602385", "A4B35A5745");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("304", "Soionbaratauri", "a:3:{i:0;i:793;i:1;i:784;i:2;i:0;}", "1106602385", "8BB1B6DEDC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("305", "Solioneschsan", "a:3:{i:0;i:204;i:1;i:95;i:2;i:0;}", "1106602385", "3F1C825F68");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("306", "Alionburatau", "a:3:{i:0;i:838;i:1;i:552;i:2;i:0;}", "1106602385", "B81A069D55");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("307", "Solphaba", "a:3:{i:0;i:580;i:1;i:155;i:2;i:0;}", "1106602385", "B62A3ECA59");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("308", "Robu", "a:3:{i:0;i:145;i:1;i:584;i:2;i:0;}", "1106602386", "67983815F8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("309", "Ormebusan", "a:3:{i:0;i:165;i:1;i:687;i:2;i:0;}", "1106602386", "0CB9D8FD18");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("310", "Almueschsan", "a:3:{i:0;i:528;i:1;i:381;i:2;i:0;}", "1106602386", "3C8FB41B41");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("311", "Sodebu Cenanri", "a:3:{i:0;i:716;i:1;i:610;i:2;i:0;}", "1106602386", "3D2C61F954");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("312", "Rodebaratau", "a:3:{i:0;i:510;i:1;i:215;i:2;i:0;}", "1106602386", "E1A92547D1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("313", "Somelu Cen", "a:3:{i:0;i:334;i:1;i:558;i:2;i:0;}", "1106602387", "B4B20A48DC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("314", "Solioneschratau", "a:3:{i:0;i:212;i:1;i:190;i:2;i:0;}", "1106602387", "54CA4F26C0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("315", "Aldeeschraanri", "a:3:{i:0;i:741;i:1;i:307;i:2;i:0;}", "1106602387", "EDE3338CD0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("316", "Orbubu Centau", "a:3:{i:0;i:473;i:1;i:344;i:2;i:0;}", "1106602387", "782B752FDF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("317", "Albulu Centauri", "a:3:{i:0;i:848;i:1;i:140;i:2;i:0;}", "1106602387", "9937B93D0A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("318", "Solme", "a:3:{i:0;i:811;i:1;i:444;i:2;i:0;}", "1106602388", "37B63E8167");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("319", "Kaionlu Cen", "a:3:{i:0;i:239;i:1;i:500;i:2;i:0;}", "1106602388", "78AE0C3FA1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("320", "Orphalu Centauri", "a:3:{i:0;i:202;i:1;i:629;i:2;i:0;}", "1106602388", "0C6A4DFA63");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("321", "Somubus", "a:3:{i:0;i:336;i:1;i:275;i:2;i:0;}", "1106602388", "0EED616AFD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("322", "Almeluraan", "a:3:{i:0;i:190;i:1;i:205;i:2;i:0;}", "1106602388", "5F509A989F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("323", "Kaioneschsanri", "a:3:{i:0;i:886;i:1;i:781;i:2;i:0;}", "1106602389", "F312D9A1F4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("324", "Kamelu Cenan", "a:3:{i:0;i:511;i:1;i:357;i:2;i:0;}", "1106602389", "714529A701");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("325", "Ormeba Cenanri", "a:3:{i:0;i:258;i:1;i:634;i:2;i:0;}", "1106602389", "84ECAA328B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("326", "Nadeesch", "a:3:{i:0;i:614;i:1;i:748;i:2;i:0;}", "1106602389", "D4971EDE7E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("327", "Kaioneschsan", "a:3:{i:0;i:447;i:1;i:105;i:2;i:0;}", "1106602389", "4A0387F5C6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("328", "Nameba", "a:3:{i:0;i:691;i:1;i:689;i:2;i:0;}", "1106602390", "710744DD5A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("329", "Naphabas", "a:3:{i:0;i:159;i:1;i:322;i:2;i:0;}", "1106602390", "1163037F30");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("330", "Namebaraanri", "a:3:{i:0;i:411;i:1;i:803;i:2;i:0;}", "1106602390", "3529CCB8B6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("331", "Romelu", "a:3:{i:0;i:573;i:1;i:302;i:2;i:0;}", "1106602390", "0656332656");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("332", "Kamebas", "a:3:{i:0;i:923;i:1;i:678;i:2;i:0;}", "1106602390", "AF21742901");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("333", "Orphalu", "a:3:{i:0;i:916;i:1;i:422;i:2;i:0;}", "1106602391", "1544021303");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("334", "Solbubastau", "a:3:{i:0;i:498;i:1;i:63;i:2;i:0;}", "1106602391", "DAB2DE7FDE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("335", "Aldebaraanri", "a:3:{i:0;i:862;i:1;i:102;i:2;i:0;}", "1106602391", "0ECAAEBFD4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("336", "Orionbara", "a:3:{i:0;i:923;i:1;i:548;i:2;i:0;}", "1106602391", "DF12854846");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("337", "Romelusanri", "a:3:{i:0;i:177;i:1;i:135;i:2;i:0;}", "1106602392", "E4BC42EDD8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("338", "Solmelus", "a:3:{i:0;i:539;i:1;i:362;i:2;i:0;}", "1106602392", "4290D7F47C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("339", "Kaphabu Cenanri", "a:3:{i:0;i:621;i:1;i:377;i:2;i:0;}", "1106602392", "406AE1FBA5");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("340", "Solmebu Cen", "a:3:{i:0;i:598;i:1;i:720;i:2;i:0;}", "1106602392", "AA0115906A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("341", "Nabuesch", "a:3:{i:0;i:663;i:1;i:66;i:2;i:0;}", "1106602392", "17FB8515D7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("342", "Sodebustauri", "a:3:{i:0;i:702;i:1;i:277;i:2;i:0;}", "1106602393", "34EF26C5A0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("343", "Albuesch", "a:3:{i:0;i:379;i:1;i:353;i:2;i:0;}", "1106602393", "8B011E0AC2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("344", "Orphabastauri", "a:3:{i:0;i:123;i:1;i:267;i:2;i:0;}", "1106602393", "36C325E489");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("345", "Solionbaratau", "a:3:{i:0;i:827;i:1;i:369;i:2;i:0;}", "1106602393", "3BD06E0828");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("346", "Almuesch", "a:3:{i:0;i:262;i:1;i:457;i:2;i:0;}", "1106602393", "8967B104D8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("347", "Namuesch Cenan", "a:3:{i:0;i:597;i:1;i:102;i:2;i:0;}", "1106602394", "C96E1FEA75");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("348", "Robubara", "a:3:{i:0;i:570;i:1;i:491;i:2;i:0;}", "1106602394", "673828A084");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("349", "Sodebaraan", "a:3:{i:0;i:617;i:1;i:52;i:2;i:0;}", "1106602394", "F499303308");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("350", "Rophabasan", "a:3:{i:0;i:772;i:1;i:736;i:2;i:0;}", "1106602394", "7DB86F2C8B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("351", "Roionbara", "a:3:{i:0;i:607;i:1;i:438;i:2;i:0;}", "1106602394", "86DD250206");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("352", "Rodeeschstau", "a:3:{i:0;i:212;i:1;i:391;i:2;i:0;}", "1106602395", "6D9B9DF586");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("353", "Kaphabara", "a:3:{i:0;i:371;i:1;i:581;i:2;i:0;}", "1106602395", "662FBD95FA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("354", "Albuburatau", "a:3:{i:0;i:640;i:1;i:534;i:2;i:0;}", "1106602431", "C3A6CA0272");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("355", "Nadebu Cen", "a:3:{i:0;i:598;i:1;i:742;i:2;i:0;}", "1106602432", "FECB8D3DFB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("356", "Kamubastau", "a:3:{i:0;i:662;i:1;i:349;i:2;i:0;}", "1106602432", "F85F824183");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("357", "Sodelu Cenan", "a:3:{i:0;i:459;i:1;i:284;i:2;i:0;}", "1106602432", "A7CC5BAAA8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("358", "Rodeba Cenan", "a:3:{i:0;i:482;i:1;i:815;i:2;i:0;}", "1106602432", "8F32F9C5FA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("359", "Nameesch", "a:3:{i:0;i:908;i:1;i:569;i:2;i:0;}", "1106602432", "56475BF229");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("360", "Kamubu Cen", "a:3:{i:0;i:196;i:1;i:515;i:2;i:0;}", "1106602433", "FDF869670A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("361", "Solmubara", "a:3:{i:0;i:717;i:1;i:207;i:2;i:0;}", "1106602433", "2811D7389E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("362", "Alphaesch", "a:3:{i:0;i:104;i:1;i:362;i:2;i:0;}", "1106602433", "1F2C97209C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("363", "Naphabus", "a:3:{i:0;i:639;i:1;i:490;i:2;i:0;}", "1106602433", "2513A93F94");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("364", "Nabulu Cenan", "a:3:{i:0;i:329;i:1;i:193;i:2;i:0;}", "1106602433", "127E920636");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("365", "Naionbasanri", "a:3:{i:0;i:428;i:1;i:227;i:2;i:0;}", "1106602433", "A448576BCE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("366", "Solphaburaanri", "a:3:{i:0;i:585;i:1;i:224;i:2;i:0;}", "1106602434", "BA10AEC8FB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("367", "Kameluraanri", "a:3:{i:0;i:848;i:1;i:740;i:2;i:0;}", "1106602434", "CF92A6DE1A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("368", "Somuburaan", "a:3:{i:0;i:751;i:1;i:719;i:2;i:0;}", "1106602434", "E755B459F9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("369", "Kamuesch Cen", "a:3:{i:0;i:914;i:1;i:55;i:2;i:0;}", "1106602434", "2382738C3A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("370", "Orbueschstau", "a:3:{i:0;i:267;i:1;i:401;i:2;i:0;}", "1106602434", "0709713D20");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("371", "Someburatauri", "a:3:{i:0;i:743;i:1;i:396;i:2;i:0;}", "1106602435", "EB2C154D3C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("372", "Solmeeschraanri", "a:3:{i:0;i:524;i:1;i:427;i:2;i:0;}", "1106602436", "56F5A3305D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("373", "Aldeesch Cen", "a:3:{i:0;i:457;i:1;i:468;i:2;i:0;}", "1106602436", "DA43CF6525");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("374", "Someba", "a:3:{i:0;i:666;i:1;i:150;i:2;i:0;}", "1106602437", "1A023A6741");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("375", "Naionba Cenanri", "a:3:{i:0;i:829;i:1;i:163;i:2;i:0;}", "1106602437", "D1227BA1D0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("376", "Sophaba Cen", "a:3:{i:0;i:176;i:1;i:794;i:2;i:0;}", "1106602438", "652421C015");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("377", "Kaioneschratau", "a:3:{i:0;i:555;i:1;i:588;i:2;i:0;}", "1106602438", "82A3A3C64C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("378", "Kaphaburatauri", "a:3:{i:0;i:340;i:1;i:497;i:2;i:0;}", "1106602439", "2280B0A575");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("379", "Alionbas", "a:3:{i:0;i:339;i:1;i:206;i:2;i:0;}", "1106602440", "AF6495D271");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("380", "Kabubusan", "a:3:{i:0;i:707;i:1;i:90;i:2;i:0;}", "1106602441", "C11305B6C7");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("381", "Sodeesch Centauri", "a:3:{i:0;i:451;i:1;i:332;i:2;i:0;}", "1106602442", "514A22EE60");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("382", "Romuba Centau", "a:3:{i:0;i:160;i:1;i:465;i:2;i:0;}", "1106602443", "05892FAB34");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("383", "Solphaba Cen", "a:3:{i:0;i:331;i:1;i:626;i:2;i:0;}", "1106602444", "97E3A10B76");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("384", "Kameesch", "a:3:{i:0;i:255;i:1;i:277;i:2;i:0;}", "1106602445", "8FE231CEF9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("385", "Rodeesch Centauri", "a:3:{i:0;i:322;i:1;i:84;i:2;i:0;}", "1106602445", "6897F8695C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("386", "Solphaeschratauri", "a:3:{i:0;i:662;i:1;i:71;i:2;i:0;}", "1106602446", "0508BCBDD6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("387", "Somueschra", "a:3:{i:0;i:248;i:1;i:195;i:2;i:0;}", "1106602447", "ABF569B885");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("388", "Alionlu", "a:3:{i:0;i:380;i:1;i:800;i:2;i:0;}", "1106602448", "8590284840");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("389", "Solmelu Centauri", "a:3:{i:0;i:134;i:1;i:701;i:2;i:0;}", "1106602449", "DBFDB65F1D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("390", "Kaionbaratauri", "a:3:{i:0;i:127;i:1;i:396;i:2;i:0;}", "1106602450", "DD4CCD11BF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("391", "Roionbusan", "a:3:{i:0;i:652;i:1;i:282;i:2;i:0;}", "1106602450", "6A65E46623");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("392", "Rophabas", "a:3:{i:0;i:611;i:1;i:239;i:2;i:0;}", "1106602451", "BE474DCA7F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("393", "Sodebu", "a:3:{i:0;i:518;i:1;i:690;i:2;i:0;}", "1106602452", "E9F07947EC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("394", "Kabueschraanri", "a:3:{i:0;i:113;i:1;i:510;i:2;i:0;}", "1106602453", "9B4F3D43A3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("395", "Solmubaratau", "a:3:{i:0;i:778;i:1;i:527;i:2;i:0;}", "1106602453", "18DBAB1CB2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("396", "Soionluratauri", "a:3:{i:0;i:276;i:1;i:272;i:2;i:0;}", "1106602454", "61A4480F24");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("397", "Alionba", "a:3:{i:0;i:890;i:1;i:331;i:2;i:0;}", "1106602455", "BF9BF6A627");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("398", "Roion", "a:3:{i:0;i:462;i:1;i:788;i:2;i:0;}", "1106602456", "F60F358502");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("399", "Sodelura", "a:3:{i:0;i:398;i:1;i:111;i:2;i:0;}", "1106602456", "759F6E66F0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("400", "Kabubus", "a:3:{i:0;i:644;i:1;i:483;i:2;i:0;}", "1106602457", "E66FF128BD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("401", "Almuesch Cenanri", "a:3:{i:0;i:242;i:1;i:709;i:2;i:0;}", "1106602473", "3AB82D5083");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("402", "Almubus", "a:3:{i:0;i:818;i:1;i:127;i:2;i:0;}", "1106602473", "1F9CB3B9E2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("403", "Kaphaba", "a:3:{i:0;i:511;i:1;i:313;i:2;i:0;}", "1106602473", "846BF25C89");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("404", "Rode", "a:3:{i:0;i:254;i:1;i:631;i:2;i:0;}", "1106602474", "A1384A928F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("405", "Namubusan", "a:3:{i:0;i:173;i:1;i:208;i:2;i:0;}", "1106602474", "CF3EA7946B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("406", "Soldebu Centau", "a:3:{i:0;i:110;i:1;i:77;i:2;i:0;}", "1106602474", "32BBD60F0E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("407", "Kamelu", "a:3:{i:0;i:155;i:1;i:620;i:2;i:0;}", "1106602474", "46CA3FE8CD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("408", "Soionbu Cen", "a:3:{i:0;i:338;i:1;i:282;i:2;i:0;}", "1106602474", "451324D505");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("409", "Ordelusan", "a:3:{i:0;i:160;i:1;i:716;i:2;i:0;}", "1106602475", "428FB2744F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("410", "Ormeesch", "a:3:{i:0;i:278;i:1;i:284;i:2;i:0;}", "1106602475", "9C6D407E4C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("411", "Ormeburatauri", "a:3:{i:0;i:802;i:1;i:753;i:2;i:0;}", "1106602546", "5B9F81B712");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("412", "Ormulustau", "a:3:{i:0;i:451;i:1;i:731;i:2;i:0;}", "1106602547", "6FD28BA3E9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("413", "Solionbara", "a:3:{i:0;i:776;i:1;i:640;i:2;i:0;}", "1106602557", "7B004409FF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("414", "Kaionesch Centauri", "a:3:{i:0;i:696;i:1;i:60;i:2;i:0;}", "1106602559", "E98FDCA0CF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("415", "Romuba", "a:3:{i:0;i:592;i:1;i:55;i:2;i:0;}", "1106602562", "7B08E34D8B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("416", "Rodelus", "a:3:{i:0;i:107;i:1;i:445;i:2;i:0;}", "1106602562", "E2FF54DB85");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("417", "Solbulustauri", "a:3:{i:0;i:920;i:1;i:545;i:2;i:0;}", "1106602563", "CEFFFBBA16");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("418", "Romebaraanri", "a:3:{i:0;i:520;i:1;i:353;i:2;i:0;}", "1106602563", "61FF47AB77");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("419", "Romeba Cenan", "a:3:{i:0;i:103;i:1;i:492;i:2;i:0;}", "1106602563", "CA8A77FDDA");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("420", "Aldebura", "a:3:{i:0;i:596;i:1;i:282;i:2;i:0;}", "1106602563", "35A5FE83CB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("421", "Namueschratau", "a:3:{i:0;i:419;i:1;i:504;i:2;i:0;}", "1106602563", "5E8C837C05");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("422", "Solmebas", "a:3:{i:0;i:852;i:1;i:541;i:2;i:0;}", "1106602564", "70C977EB20");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("423", "Alionesch Cen", "a:3:{i:0;i:153;i:1;i:132;i:2;i:0;}", "1106602566", "F2109AD797");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("424", "Kameeschra", "a:3:{i:0;i:638;i:1;i:674;i:2;i:0;}", "1106602566", "626E71002C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("425", "Ordebusanri", "a:3:{i:0;i:220;i:1;i:392;i:2;i:0;}", "1106602566", "7DF644B74B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("426", "Roionesch Centauri", "a:3:{i:0;i:775;i:1;i:121;i:2;i:0;}", "1106602566", "9D3D43CA6D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("427", "Someba Cenanri", "a:3:{i:0;i:799;i:1;i:69;i:2;i:0;}", "1106602567", "42286C8713");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("428", "Orphabaratauri", "a:3:{i:0;i:521;i:1;i:725;i:2;i:0;}", "1106602567", "B144EDDE02");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("429", "Albubara", "a:3:{i:0;i:262;i:1;i:305;i:2;i:0;}", "1106602567", "F56AF81F57");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("430", "Alphaba", "a:3:{i:0;i:596;i:1;i:555;i:2;i:0;}", "1106602567", "4994FFB372");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("431", "Soion", "a:3:{i:0;i:445;i:1;i:442;i:2;i:0;}", "1106602567", "8C35A5B5F4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("432", "Aldebu", "a:3:{i:0;i:635;i:1;i:138;i:2;i:0;}", "1106602568", "C0B4E21D7C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("433", "Albubasan", "a:3:{i:0;i:736;i:1;i:63;i:2;i:0;}", "1106602568", "2EE60126BF");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("434", "Robubu", "a:3:{i:0;i:598;i:1;i:370;i:2;i:0;}", "1106602568", "9C83A100F1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("435", "Robulu Cenan", "a:3:{i:0;i:840;i:1;i:90;i:2;i:0;}", "1106602568", "B1EF8447A9");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("436", "Ordeba Cenan", "a:3:{i:0;i:412;i:1;i:722;i:2;i:0;}", "1106602568", "C08A63DBCE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("437", "Almeba", "a:3:{i:0;i:645;i:1;i:603;i:2;i:0;}", "1106602568", "E1FC4BE4E3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("438", "Rophaluraan", "a:3:{i:0;i:408;i:1;i:500;i:2;i:0;}", "1106602569", "A642A0F1C2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("439", "Roionluratau", "a:3:{i:0;i:676;i:1;i:410;i:2;i:0;}", "1106602569", "325DCA0B40");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("440", "Roionbas", "a:3:{i:0;i:746;i:1;i:251;i:2;i:0;}", "1106602570", "E5209AD119");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("441", "Solionluratau", "a:3:{i:0;i:126;i:1;i:679;i:2;i:0;}", "1106602570", "2CA290ACF6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("442", "Albulu Cen", "a:3:{i:0;i:628;i:1;i:181;i:2;i:0;}", "1106602570", "E12C300A30");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("443", "Sophaesch Centau", "a:3:{i:0;i:227;i:1;i:75;i:2;i:0;}", "1106602570", "318E8C8BD0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("444", "Solionbaraanri", "a:3:{i:0;i:558;i:1;i:591;i:2;i:0;}", "1106602571", "9543372899");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("445", "Kabueschs", "a:3:{i:0;i:576;i:1;i:806;i:2;i:0;}", "1106602571", "0613E4B092");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("446", "Naionbu", "a:3:{i:0;i:506;i:1;i:544;i:2;i:0;}", "1106602571", "1BF8A1882C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("447", "Roionbaraanri", "a:3:{i:0;i:786;i:1;i:730;i:2;i:0;}", "1106602571", "92BB6BE97E");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("448", "Almulu", "a:3:{i:0;i:864;i:1;i:365;i:2;i:0;}", "1106602571", "9052A7B72C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("449", "Solmebu Centauri", "a:3:{i:0;i:274;i:1;i:84;i:2;i:0;}", "1106602572", "DB2D523F78");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("450", "Nadelustau", "a:3:{i:0;i:595;i:1;i:739;i:2;i:0;}", "1106602572", "8487FFBC11");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("451", "Rophaeschraanri", "a:3:{i:0;i:877;i:1;i:637;i:2;i:0;}", "1106602572", "3579002292");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("452", "Rodeesch", "a:3:{i:0;i:427;i:1;i:684;i:2;i:0;}", "1106602572", "E69F462881");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("453", "Solphalu Cen", "a:3:{i:0;i:693;i:1;i:79;i:2;i:0;}", "1106602573", "28961FBB27");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("454", "Almeesch", "a:3:{i:0;i:301;i:1;i:614;i:2;i:0;}", "1106602573", "CA78A5A48B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("455", "Ordeeschsan", "a:3:{i:0;i:515;i:1;i:60;i:2;i:0;}", "1106602573", "7CDB52F7E3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("456", "Orbubu Cen", "a:3:{i:0;i:720;i:1;i:84;i:2;i:0;}", "1106602573", "6F7C3133A6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("457", "Robuba", "a:3:{i:0;i:200;i:1;i:420;i:2;i:0;}", "1106602573", "628F58977B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("458", "Orionbastau", "a:3:{i:0;i:856;i:1;i:544;i:2;i:0;}", "1106602574", "DCC52EC7F4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("459", "Orioneschstauri", "a:3:{i:0;i:728;i:1;i:810;i:2;i:0;}", "1106602574", "4C0DA5D4FD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("460", "Sodebus", "a:3:{i:0;i:899;i:1;i:152;i:2;i:0;}", "1106602574", "1EEAA02FC3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("461", "Solphalus", "a:3:{i:0;i:459;i:1;i:660;i:2;i:0;}", "1106602574", "CF305403EC");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("462", "Aldebu Cenanri", "a:3:{i:0;i:866;i:1;i:754;i:2;i:0;}", "1106602574", "B5CEDC73E5");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("463", "Nadebu", "a:3:{i:0;i:692;i:1;i:84;i:2;i:0;}", "1106602575", "CC8EADDB1C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("464", "Nabueschstauri", "a:3:{i:0;i:374;i:1;i:387;i:2;i:0;}", "1106602575", "FB5179FFE4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("465", "Sobubaratauri", "a:3:{i:0;i:825;i:1;i:810;i:2;i:0;}", "1106602575", "3A88C6331D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("466", "Nadeburatau", "a:3:{i:0;i:523;i:1;i:563;i:2;i:0;}", "1106602575", "9F97E3E671");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("467", "Nadelura", "a:3:{i:0;i:686;i:1;i:499;i:2;i:0;}", "1106602575", "9465102A49");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("468", "Orphabu Cenan", "a:3:{i:0;i:922;i:1;i:159;i:2;i:0;}", "1106602576", "4F868ABBA0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("469", "Aldelusanri", "a:3:{i:0;i:156;i:1;i:418;i:2;i:0;}", "1106602576", "A8106F8E41");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("470", "Roionba Cen", "a:3:{i:0;i:568;i:1;i:483;i:2;i:0;}", "1106602576", "A2DB1350F8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("471", "Somebu", "a:3:{i:0;i:605;i:1;i:649;i:2;i:0;}", "1106602576", "1A5BF83201");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("472", "Solphaluraan", "a:3:{i:0;i:828;i:1;i:714;i:2;i:0;}", "1106602576", "1CEEA5A6A4");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("473", "Soldelu Centauri", "a:3:{i:0;i:309;i:1;i:587;i:2;i:0;}", "1106602577", "54D7EE38BB");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("474", "Ormulusan", "a:3:{i:0;i:196;i:1;i:739;i:2;i:0;}", "1106602577", "EF77534003");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("475", "Aldeesch Cenan", "a:3:{i:0;i:644;i:1;i:183;i:2;i:0;}", "1106602577", "EC4D9E90D0");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("476", "Romeba", "a:3:{i:0;i:621;i:1;i:274;i:2;i:0;}", "1106602577", "AD19418D35");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("477", "Kadebus", "a:3:{i:0;i:672;i:1;i:658;i:2;i:0;}", "1106602577", "ECE797EB00");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("478", "Naionesch Centauri", "a:3:{i:0;i:814;i:1;i:75;i:2;i:0;}", "1106602578", "0282DB628B");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("479", "Soldeba Cenanri", "a:3:{i:0;i:231;i:1;i:226;i:2;i:0;}", "1106602578", "3F3233CD19");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("480", "Sodelu Cenanri", "a:3:{i:0;i:251;i:1;i:552;i:2;i:0;}", "1106602578", "C338E0BD99");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("481", "Roionbu", "a:3:{i:0;i:189;i:1;i:684;i:2;i:0;}", "1106602578", "93858E8DFE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("482", "Solmubustauri", "a:3:{i:0;i:868;i:1;i:592;i:2;i:0;}", "1106602578", "4935515090");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("483", "Namebura", "a:3:{i:0;i:623;i:1;i:341;i:2;i:0;}", "1106602579", "01CDFD5D16");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("484", "Romelustau", "a:3:{i:0;i:856;i:1;i:315;i:2;i:0;}", "1106602579", "DAB6852829");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("485", "Kabuba Cenan", "a:3:{i:0;i:774;i:1;i:502;i:2;i:0;}", "1106602579", "E1B754439F");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("486", "Orphalu Cen", "a:3:{i:0;i:122;i:1;i:752;i:2;i:0;}", "1106602579", "002D6A2F44");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("487", "Orioneschra", "a:3:{i:0;i:697;i:1;i:655;i:2;i:0;}", "1106602579", "59E41FBEF3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("488", "Alphalu Cen", "a:3:{i:0;i:373;i:1;i:190;i:2;i:0;}", "1106602580", "5989C217B8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("489", "Ormubasanri", "a:3:{i:0;i:220;i:1;i:567;i:2;i:0;}", "1106602580", "FD00DB7832");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("490", "Rodeluratau", "a:3:{i:0;i:870;i:1;i:403;i:2;i:0;}", "1106602580", "B68027F1B3");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("491", "Kabubas", "a:3:{i:0;i:162;i:1;i:554;i:2;i:0;}", "1106602580", "B8E4FE2620");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("492", "Orbuba", "a:3:{i:0;i:817;i:1;i:558;i:2;i:0;}", "1106602580", "54E85C66BD");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("493", "Kadeesch", "a:3:{i:0;i:362;i:1;i:809;i:2;i:0;}", "1106602581", "20F3F81ECE");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("494", "Solmulu", "a:3:{i:0;i:147;i:1;i:444;i:2;i:0;}", "1106602581", "D0083B199A");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("495", "Orphaba Centau", "a:3:{i:0;i:842;i:1;i:457;i:2;i:0;}", "1106602581", "CA48C84C95");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("496", "Aldelu", "a:3:{i:0;i:536;i:1;i:682;i:2;i:0;}", "1106602581", "3006D07659");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("497", "Sobuba Cen", "a:3:{i:0;i:882;i:1;i:608;i:2;i:0;}", "1106602581", "93A9FF2630");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("498", "Sophabu Cen", "a:3:{i:0;i:422;i:1;i:315;i:2;i:0;}", "1106602582", "1BB89374C6");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("499", "Someluraan", "a:3:{i:0;i:759;i:1;i:621;i:2;i:0;}", "1106602582", "85133F5B38");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("500", "Orionba Cen", "a:3:{i:0;i:127;i:1;i:723;i:2;i:0;}", "1106602582", "BBA3C4C03C");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("501", "Kabulu Cenanri", "a:3:{i:0;i:360;i:1;i:599;i:2;i:0;}", "1106602582", "87CCCAA3D8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("502", "Solphaesch Cen", "a:3:{i:0;i:260;i:1;i:243;i:2;i:0;}", "1106602583", "75215246E2");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("503", "Aldebasanri", "a:3:{i:0;i:410;i:1;i:638;i:2;i:0;}", "1106603509", "35D0E7C7E1");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("504", "Aldeba", "a:3:{i:0;i:340;i:1;i:600;i:2;i:0;}", "1106778088", "78A9A7628D");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("505", "Kamelu Cenanri", "a:3:{i:0;i:723;i:1;i:468;i:2;i:0;}", "1106778094", "03F62E22B8");
INSERT INTO `systems_index` (`system_id`, `system_name`, `system_location`, `date`, `activ`) VALUES("506", "Ormebus", "a:3:{i:0;i:467;i:1;i:56;i:2;i:0;}", "1106778096", "66446E65A9");


#
# Table structure for table 'systems_link'
#

DROP TABLE IF EXISTS `systems_link`;
CREATE TABLE `systems_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `system_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'systems_link'
#



#
# Table structure for table 'users_index'
#

DROP TABLE IF EXISTS `users_index`;
CREATE TABLE `users_index` (
  `user_id` int(15) unsigned default '0',
  `username` varchar(100) default NULL,
  `password` varchar(32) default '0',
  `date` int(15) unsigned default '0',
  `activ` varchar(32) default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'users_index'
#

INSERT INTO `users_index` (`user_id`, `username`, `password`, `date`, `activ`) VALUES("1", "Amun", "1cd96303d9cdb4210c945a163133964a", "1099832296", "0");
INSERT INTO `users_index` (`user_id`, `username`, `password`, `date`, `activ`) VALUES("2", "Dummy", "098f6bcd4621d373cade4e832627b4f6", "1099832638", "0");


#
# Table structure for table 'users_link'
#

DROP TABLE IF EXISTS `users_link`;
CREATE TABLE `users_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `user_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'users_link'
#

INSERT INTO `users_link` (`category`, `value`, `user_id`) VALUES("email", "Amun@hausswolff.de", "1");
INSERT INTO `users_link` (`category`, `value`, `user_id`) VALUES("email", "test@hausswolff.de", "2");
