<?php
$f['m'] = 'w';
$f['l'] = '_';
$f['r'] = '_';
$f['o'] = '_';
$f['u'] = '_';
$seiten = array('m', 'l', 'r', 'o', 'u');
foreach($seiten as $seite)
	if($_REQUEST[$seite])
		$f[$seite] = $_REQUEST[$seite];

$filename = "tiles/".$f['m']."_".$f['l']."_".$f['r']."_".$f['o']."_".$f['u'].".png";


//$tile = imagecreatetruecolor(70, 35);
if($f['m'] == "i"){
	$bgimg = imagecreatetruecolor(70, 35);
	$col['i'] = ImageColorAllocate($tile, 206, 238, 255);
	imagefill($tile, 0, 0, $col[$f['m']]);
	//$tile = imagecreatefrompng("i.png");
}
elseif($f['m'] == "l")
	$bgimg = imagecreatefrompng("l.png");
elseif($f['m'] == "m")
	$bgimg = imagecreatefrompng("m.png");
elseif($f['m'] == "d")
	$bgimg = imagecreatefrompng("d.png");
elseif($f['m'] == "f")
	$bgimg = imagecreatefrompng("f.png");
elseif($f['m'] == "n")
	$bgimg = imagecreatefrompng("n.png");

else
	$bgimg = imagecreatefrompng("w.png");

$trans = ImageColorAllocate($bgimg, 254, 254, 254);

imagerotate ($bgimg, 30, $trans);


$tile = imagecreatetruecolor(70, 35);

//ImageCopy ( int dst_im, int src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h)
ImageCopy($tile, $bgimg,  0, 0, 0, 0, 70, 35);

$white = ImageColorAllocate($tile, 255, 255, 255);
$black = ImageColorAllocate($tile, 0, 0, 0);
$yellow = ImageColorAllocate($tile, 255, 255, 0);
$trans = ImageColorAllocate($tile, 254, 254, 254);

$col['w'] = ImageColorAllocate($tile, 45, 167, 242);
$col['n'] = ImageColorAllocate($tile, 33, 119, 31);
$col['m'] = ImageColorAllocate($tile, 114, 115, 109);

$col['l'] = ImageColorAllocate($tile, 115, 191, 54);

$col['f'] = ImageColorAllocate($tile, 130, 50, 11);

$col['d'] = ImageColorAllocate($tile, 233, 223, 191);
$col['i'] = ImageColorAllocate($tile, 206, 238, 255);



//$w = 35; $h = 15;

//imagefill($tile, 0, 0, $col[$f['m']]);

//Bogen oben
$s = 2*-26.57;
if($f['l'] != '_')
imagefilledarc($tile, 0, 0, 85, 35, $s, $s + 180, $col[$f['l']], IMG_ARC_PIE);

//Bogen links
$s = $s + 90;
if($f['o'] != '_')
imagefilledarc($tile, 70, 0, 85, 35, $s, $s + 180, $col[$f['o']], IMG_ARC_PIE);

//Bogen rechts
$s = $s + 90;
if($f['r'] != '_')
imagefilledarc($tile, 70, 35, 85, 35, $s, $s + 180, $col[$f['r']], IMG_ARC_PIE);

//Bogen unten
$s = $s + 90;
if($f['u'] != '_')
imagefilledarc($tile, 0, 35, 85, 35, $s, $s + 180, $col[$f['u']], IMG_ARC_PIE);

//imagefilledellipse ( resource image, int cx, int cy, int w, int h, int color)
//imagefilledellipse($tile, 35, 0, 25, 30, $col[$f['o']]);
//imagefilledellipse($tile, 35, 35, 25, 30, $col[$f['u']]);
//imagefilledellipse($tile, 0, 17, 30, 25, $col[$f['l']]);
//imagefilledellipse($tile, 70, 17, 30, 25, $col[$f['r']]);


$trans = imagecolortransparent($tile, $trans);

//Ecke links oben
imagefilledpolygon ($tile, array("0", "17", "0", "0", "35", "0", "0", "17"), 4, $trans);

//Ecke rechts oben
imagefilledpolygon ($tile, array("35", "0", "70", "0", "70", "17", "35", "0"), 4, $trans);

//Ecke rechts unten
imagefilledpolygon ($tile, array("70", "17", "70", "35", "35", "35", "70", "17"), 4, $trans);

//Ecke links unten
imagefilledpolygon ($tile, array("35", "35", "0", "17", "0", "35", "35", "35"), 4, $trans);


imageinterlace($tile,1);

header("Content-Type: image/png");
$file = $tile;
imagepng($file, $filename);

imagepng($tile);
imagedestroy($tile);

?>