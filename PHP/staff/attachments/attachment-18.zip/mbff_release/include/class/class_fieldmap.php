<?php
class c_fieldmap {
	var $layer = 0;
	
	var $fields_blocked = array();
	var $fields_content = array();
	var $fields_height = array();

	var $x_count = "";
	var $y_count = "";

	var $x_offset = 0;
	var $y_offset = 0;
	
	var $w = ""; 
	var $h = "";
	var $w2 = "";
	var $h2 = "";

	var $border = 1;
	var $url;
	
	var $img_path = "world/system/fields/";
	var $img_pushed = "trans_tiles_small_pushed.png";
	var $img_basic = "trans_tiles_small.png";	
	var $map_typ = "iso";

	function c_fieldmap($x = 15, $y = 45, $url = ""){
		$this->x_count = $x;
		$this->y_count = $y;
		$this->url = $url;
	}

	function set_layer($layer){
		$this->layer = $layer;
	}

	function set_border($border){
		$this->border = $border;
	}
	
	function set_offset($x, $y){
		$this->x_offset += $x;
		$this->y_offset += $y;
	}
	
	function set_map_typ($map_typ){
		$this->map_typ = $map_typ;
	}
	
	function set_tile_size($w = 70, $h = 35){
		$this->h = $h;
		$this->w = $w;
		$this->w2 = ceil($w/2);
		$this->h2 = ceil($h/2);
		$this->x_offset = $this->w2;
		//$this->y_offset = $this->h2;
	}

	function draw(){
		for($y = 0; $y < $this->y_count; $y++){
			$this->layer += 1;
			for($x = 0; $x < $this->x_count; $x++){
				if($y % 2 == 0)
					$x_pos = $this->x_offset - $this->w2 + ($this->w * $x);
				else
					$x_pos = $this->x_offset + ($this->w * $x);
				
				$y_pos = $this->y_offset + $y * ($this->h2 + $this->border) - $this->fields_height[$x][$y]; 
				$pic_count += 1;

				echo "<div style=\"position:absolute; z-index:".$this->layer."; width:".$this->w."px; height:".$this->h."px; left:".$x_pos."px;top:".$y_pos."px;\">\n";
				echo "\t<a onmouseover=\"bild".$pic_count.".src='".$this->img_path.$this->map_typ."/".$this->img_pushed."'\" onmouseout=\"bild".$pic_count.".src='".$this->img_path.$this->map_typ."/".$this->img_basic."'\" href=\"".$this->url."\"><img name=\"bild".$pic_count."\" src=\"".$this->img_path.$this->map_typ."/".$this->img_basic."\" alt=\"\" title=\"".$x."/".$y."\" border=\"0\"></a>";
				echo "</div>\n";
			}
		}	
	}
	
	function set_field_content($content_array){
		$this->fields_content = $content_array;
	}

	function showclass(){
		echo "<pre>";
		print_r($this);
		echo "</pre>";
	}
}
?>