# MySQL-Front Dump 2.5
#
# Host: imotep   Database: mbff_level1
# --------------------------------------------------------
# Server version 4.0.18-nt


#
# Table structure for table 'sessions'
#

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `sid` varchar(32) default '0',
  `ip` varchar(30) default NULL,
  `user_id` int(15) unsigned default '0',
  `session_start` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Table structure for table 'sessions_value'
#

DROP TABLE IF EXISTS `sessions_value`;
CREATE TABLE `sessions_value` (
  `sid` varchar(32) default '0',
  `session_value_name` varchar(50) default '0',
  `session_value` text
) TYPE=MyISAM;



#
# Table structure for table 'systems_index'
#

DROP TABLE IF EXISTS `systems_index`;
CREATE TABLE `systems_index` (
  `system_id` int(15) unsigned default '0',
  `system_name` varchar(100) default NULL,
  `system_location` varchar(40) default 'a:3:{i:0;i:0000;i:1;i:0000;i:2;i:0000;}',
  `date` int(15) unsigned default '0',
  `activ` varchar(10) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'systems_link'
#

DROP TABLE IF EXISTS `systems_link`;
CREATE TABLE `systems_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `system_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Table structure for table 'users_index'
#

DROP TABLE IF EXISTS `users_index`;
CREATE TABLE `users_index` (
  `user_id` int(15) unsigned default '0',
  `username` varchar(100) default NULL,
  `password` varchar(32) default '0',
  `date` int(15) unsigned default '0',
  `activ` varchar(32) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'users_link'
#

DROP TABLE IF EXISTS `users_link`;
CREATE TABLE `users_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `user_id` int(15) unsigned default '0'
) TYPE=MyISAM;

