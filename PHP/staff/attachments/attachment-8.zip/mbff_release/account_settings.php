<?php
require("./include/base_functions.php");
require("./session.php");
require("./include/base_settings.php");

$hp['style'] = "background-image: url(images/t.space.gif);";
$hp['footer'] = hp_compressed_output();

if($user_id > 0){
	//Lese Einstellungen aus und �berpr�fe den Zustand
	for($i=0; $i < sizeof($config_name); $i++){
		$hp[settings_name] = $config_name[$i];
		$hp[settings_desc] = $config_desc[$i];
		switch($config_typ[$i]){
			case"bool":
					$url = $PHP_SELF."?sid=$sid";
					if($user->data['set_'.$config_string[$i]])
						$hp[setting_typ] = $user->data['set_'.$config_string[$i]];
					else
						$hp[setting_typ] = false;
					
					if($hp[setting_typ] == false)
						eval("\$hp['settings_status']  = \"".hp_gettemplate("settings_switch_off")."\";");		
					else
						eval("\$hp['settings_status']  = \"".hp_gettemplate("settings_switch_on")."\";");		
				break;
		}
		eval("\$hp['settings']  .= \"".hp_gettemplate("settings_row")."\";");		
	}
	eval("\$hp['menu_main']  = \"".hp_gettemplate("main_links")."\";");		
	eval("\$hp['nav']  = \"".hp_gettemplate("menu_main")."\";");	
	eval("\$hp['content']  = \"".hp_gettemplate("account_settings")."\";");

}else{
	eval("\$hp['content']  = \"".hp_gettemplate("login")."\";");
}
///////////////////////////////////////////
eval("\$index = \"".hp_gettemplate("index")."\";");
echo $index;
?>
