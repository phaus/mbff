<?php
function get_galaxy_layer(){
	global $sys_conf, $user_id;
		$filename = $sys_conf['cache_folder']."/imgs/galaxy_layer_".$user_id.".png";
		if(!@fopen($filename,"r")){
			$galaxy_layer = imagecreatetruecolor(1024, 1024);
			
			$white = ImageColorAllocate($galaxy_layer, 255, 255, 255);
			$black = ImageColorAllocate($galaxy_layer, 0, 0, 0);
			$yellow = ImageColorAllocate($galaxy_layer, 255, 255, 0);
			
			ImageFill($galaxy_layer, 0, 0, $white);
			imagecolortransparent($galaxy_layer, $white);
			
			$sys_list = new c_system_list("*");
			$sys_list->get_all_nodes(array('system_name', 'system_location'));
			$sys_arr = $sys_list->return_data_array();
			foreach($sys_arr as $sys){
				$koords = unserialize($sys['system_location']);
				$x = $koords[0]-5;
				$y = $koords[1]-5;
				imagefilledellipse ($galaxy_layer, $koords[0], $koords[1], 10, 5, $yellow);
			}

			imageinterlace($galaxy_layer,1);
			imagepng($galaxy_layer, $filename, 85);
			imagedestroy($galaxy_layer);
			if(_debug){
				global $_debug;
				$_debug->add("<b>CACHING:</b> ".$filename);
			}
		}
return $filename;
}
?>