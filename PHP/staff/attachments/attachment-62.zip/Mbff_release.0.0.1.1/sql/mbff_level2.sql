# MySQL-Front Dump 2.5
#
# Host: localhost   Database: mbff_level2
# --------------------------------------------------------
# Server version 4.0.20a-nt-log


#
# Table structure for table 'avatar_table'
#

CREATE TABLE avatar_table (
  avatar_id int(10) unsigned default '0',
  avatar_attr_id int(10) unsigned default '0',
  avatar_value text
) TYPE=MyISAM;



#
# Table structure for table 'orb_table'
#

CREATE TABLE orb_table (
  orb_id int(10) unsigned default '0',
  category varchar(100) default '0',
  value text
) TYPE=MyISAM;

