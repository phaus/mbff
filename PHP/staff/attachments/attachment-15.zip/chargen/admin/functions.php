<?
$GLOBALS["config"]="./admin/config.php";

//compressed output
function hp_compressed_output()
{
global $funccount, $hp_options;
$funccount++;

	$encoding = getEnv("HTTP_ACCEPT_ENCODING");
	$useragent = getEnv("HTTP_USER_AGENT");
	$method = trim(getEnv("REQUEST_METHOD"));
	$msie = preg_match("=msie=i", $useragent);
	$gzip = preg_match("=gzip=i", $encoding);
	if ($gzip && ($method != "POST" or !$msie))
	{
		ob_start("ob_gzhandler");
		return "<small style=\"background: #000000;color: #FFFF93;\">gzip</small>";
	}
	else
	{
		ob_start();
		return "-|-";
	}
}

//Logt Vorg�nge mit
function hp_log($eintrag = "fuu"){
global $funccount, $hp_options, $db;
$funccount++;
$logstring = "Logs vom ".date("d-m-Y");  //Titel des Threads = Sammeldatum f�r Logeintr�ge
$sql = "
SELECT threadid
FROM bb".$hp_options['forumnr']."_threads
WHERE  topic = '".$logstring."'";
$result = $db ->query($sql);
      if($db->num_rows($result) > 0){
          $thread = $db->fetch_array($result);

          $sql = "
          INSERT INTO
          bb".$hp_options['forumnr']."_posts
          (threadid, userid, username, iconid, posttime, message, showsignature, ipaddress)
          VALUES
          ('".$thread["threadid"]."', '".$hp_options['sys_userid']."', '".$hp_options['sys_user']."', '14', '".time()."', '".$eintrag."', '0', '".$hp_options['sys_userip']."')
          ";
          $db -> query($sql);

          $sql ="
          UPDATE bb".$hp_options['forumnr']."_threads
          SET  lastposttime = '".time()."', lastposterid='".$hp_options['sys_userid']."', lastposter='".$hp_options['sys_user']."',   replycount=replycount+1
          WHERE threadid = '".$thread["threadid"]."'
          ";
          $db ->query($sql);

          $sql ="
          UPDATE bb".$hp_options['forumnr']."_boards
          SET postcount=postcount+1,  lastthreadid='".$thread["threadid"]."', lastposttime = '".time()."', lastposterid = '".$hp_options['sys_userid']."', lastposter = '".$hp_options['sys_user']."'
          WHERE boardid = '".$hp_options['logs']."'
          ";
          $db ->query($sql);

      } else {

          $sql = "
          INSERT INTO
          bb".$hp_options['forumnr']."_threads
          (boardid, topic, iconid, starttime, starterid, starter, lastposttime, lastposterid, lastposter, visible)
          VALUES
          ('".$hp_options['logs']."', '".$logstring."', '14', '".time()."', '".$hp_options['sys_userid']."', '".$hp_options['sys_user']."', '".time()."', '".$hp_options['sys_userid']."', '".$hp_options['sys_user']."', '1')
          ";
          $db -> query($sql);

          $thread["threadid"] = $db -> insert_id();

          $sql = "
          INSERT INTO
          bb".$hp_options['forumnr']."_posts
          (threadid, userid, username, iconid, posttime, message, showsignature, ipaddress)
          VALUES
          ('".$thread["threadid"]."', '".$hp_options['sys_userid']."', '".$hp_options['sys_user']."', '14', '".time()."', '".$eintrag."', '0', '".$hp_options['sys_userip']."')
          ";
          $db -> query($sql);

          $sql ="
          UPDATE bb".$hp_options['forumnr']."_boards
          SET threadcount=threadcount+1,  postcount=postcount+1,  lastthreadid='".$thread["threadid"]."', lastposttime = '".time()."', lastposterid = '".$hp_options['sys_userid']."', lastposter = '".$hp_options['sys_user']."'
          WHERE boardid = '".$hp_options['logs']."'
          ";
          $db ->query($sql);

      }

$db -> free_result();
}

function do_groupdrop($name = "usergroup", $group = "", $id = "-1"){
global $funccount, $hp_options, $db;
$funccount++;
$result = $db->query("SELECT groupid FROM `bb".$hp_options['forumnr']."_groups` WHERE showchoose = '1' ORDER BY title ASC");
while($row = $db->fetch_array($result))
{
$rank = $db->query("SELECT rankid,ranktitle FROM `bb".$hp_options['forumnr']."_ranks` WHERE groupid = '".$row["groupid"]."' ");
$row2 = $db->fetch_array($rank);
$db -> free_result($rank);
#echo "Gruppe: ".$row["groupid"]." Rank: ".$row2["rankid"]."<br />\n";
$group[$c]["groupid"] = $row["groupid"];
$group[$c]["title"] = $row2["ranktitle"];
$group[$c]["rankid"] = $row2["rankid"];
$c++;
}
$db -> free_result($result);
$out = "<select class=\"input\" name=\"".$name."\">\n";
foreach($group as $part){
  if($part["groupid"] == $id OR $part["title"] == $group){
    $out .= "<option selected value='".$part["groupid"].":".$part["rankid"]."'>".$part["title"]."</option>\n";
  } else {
    $out .= "<option value='".$part["groupid"].":".$part["rankid"]."'>".$part["title"]."</option>\n";
  }
}
$out .= "<select>\n";
return $out;
}

function get_img_size($file,$js=0){
global $funccount;
$funccount++;
$string = getimagesize($file);
if($js){
$string[1] = intval($string[1])+40;
return " WIDTH=".$string[0].",HEIGHT=".$string[1];}
else{
return " (".$string[0]." x ".$string[1].")\n";}
}

function hp_thumb($folder,$filename,$newy,$width = ""){
global $config,$db,$funccount;
$funccount++;
require($config);

$bild = split("\.",$filename);

$result = $db->query("SELECT * FROM `".$hp_options['db_pics']."` WHERE pic_file = '".$filename."' ");
$num = $db->num_rows($result);
if($num > 0){
$picrow = $db->fetch_array($result);
$db -> free_result($result);
}
else{
$db -> free_result($result);
$result = $db->query("INSERT INTO `".$hp_options['db_pics']."` (pic_file,pic_name,pic_loaddate,pic_description,pic_poster,pic_posterid,pic_posterdate) VALUES ('".$filename."','".$filename."','".time()."','','SYSTEM','38','".time()."')");
$db -> free_result($result);
$result = $db->query("SELECT * FROM `".$hp_options['db_pics']."` WHERE pic_file = '".$filename."' ");
$picrow = $db->fetch_array($result);
$db -> free_result($result);
}
$title = $picrow['pic_poster']." am ".date("d.m.y, H:i",$picrow["pic_posterdate"]).":
".$picrow['pic_description']."
Bild wurde am ".date("d.m.y, H:i",$picrow["pic_loaddate"])." hochgeladen.";
if(!$width){$width = $newy;}
if(@fopen($folder."/thumb/".$bild[0]."_".$newy.".png","r")){}
else{
     $file = $folder."/".$filename;
     $imgsrcsz = getimagesize($file);
     $multi = $imgsrcsz[1]/$newy;
     $newx = $imgsrcsz[0]/$multi;
     $thumb = imagecreatetruecolor($newx, $newy);
     switch($imgsrcsz[2]){
                case"1":
                $imgsrc = imagecreatefromgif($file);
                break;
                case"2":
                $imgsrc = imagecreatefromjpeg($file);
                break;
                case"2":
                $imgsrc = imagecreatefrompng($file);
                break;
                default:
                $imgsrc = imagecreatefromwbmp($file);
                }
     imagecopyresampled($thumb,$imgsrc,0,0,0,0,$newx,$newy,$imgsrcsz[0],$imgsrcsz[1]);
     imageinterlace($thumb,1);
     imagepng($thumb,$folder."/thumb/".$bild[0]."_".$newy.".png",75);
     imagedestroy($thumb);
}
return "<p><img width='".$width."' title='".$title."' alt='".$title."' border=0 src='".$folder."/thumb/".$bild[0]."_".$newy.".png' /></p>\n<small>".$picrow["pic_name"]."".get_img_size("bilder/".$picrow["pic_file"])."</small>";
}


function hp_gallery($stylepack,$start=0,$pro_seite = 8){
global $funccount;
$funccount++;
if(!$start){$start=0;}
if(!$pro_seite){$pro_seite=8;}
$pics_in_row = 2;
$count = 1;
$seite = 0;
$handle=opendir("./bilder");
while ($file = readdir ($handle)) {
    if ($file != "." && $file != ".." && $file != "klein" && $file != "thumb" && $file != "CVS" && $file!="Thumbs.db") {
       $files[] = $file;
    }
}
closedir($handle);
sort($files);
reset($files);
$anzahl = sizeof($files);
$ende = $start + $pro_seite;
if($ende > $anzahl){$ende = $anzahl;}
$seiten = ($anzahl)/$pro_seite;
$rows = array(2,4,8,10,16,20);

//AUSWAHL BILDER / SEITE
foreach($rows as $part){
if($pro_seite == $part){
$wahl1 .= "&raquo;<a style='text-decoration:none' href='index.php?action=gallery&start=".$start."&pro_seite=".$part."'><b><big>[".$part." pro Seite]</big></b></a>&nbsp;";
}
else{
$wahl1 .= "&raquo;<a href='index.php?action=gallery&start=".$start."&pro_seite=".$part."'><small>".$part." pro Seite</small></a>&nbsp;";
}
}

//AUSWAHL SEITEN
$wahl2 = "<b>Seite &raquo;</b>";
for ($i=0;$i<$seiten;$i++){
      $s = $i*$pro_seite;
       if($s == $start){
           $wahl2 .= "<a title='aktuelle Seite (".++$seite.")' style='text-decoration:none' href='index.php?action=gallery&start=".$s."&pro_seite=".$pro_seite."'><b><big>[".$seite."]</big></b></a> ";
       }
       else{
            $wahl2 .= "<a title='zur Seite ".++$seite."' href='index.php?action=gallery&start=".$s."&pro_seite=".$pro_seite."'><small>".$seite."</small></a> ";
       }
}

$out .= "<table align='center' width='90%'>
<tr><td align='center' colspan=3><big>Bildergallery</big> <small>(".$anzahl." Bilder)</small></td></tr>\n";
$out .= "<tr><td align='right' colspan=3><br />\n".$wahl1."<hr />\n".$wahl2."\n</td></tr>\n<tr>";


for ($j=$start;$j<$ende;$j++)
{
$out .= "<td bgcolor='".$stylepack['tablecolorb']."' ONMOUSEOVER=\"this.bgColor = '".$stylepack['tablecolora']."'\" ONMOUSEOUT=\"this.bgColor = '".$stylepack['tablecolorb']."';\" style='border-color:#6F6F6F #9F9F9F #9F9F9F #6F6F6F; border-width:2px; border-style:solid;' width='33%' align=\"center\">
<a style='cursor: move' title=\"".$files[$j]."\" href=\"javascript:void(window.open('show.php?action=view&file=bilder/".$files[$j]."','Bild".$j."','".get_img_size("bilder/".$files[$j],1).",SCROLLBARS=yes,RESIZABLE=yes,TOOLBAR=NO'))\" onMouseOver=\" self.status = '".$files[$j]." anzeigen lassen'; return true\" onMouseOut=\"self.status=''; return true\" style=\"text-decoration:none\" >".hp_thumb("bilder",$files[$j],200)."</a>
<noscript>
<a style='cursor: move' target='_BILD".$files[$j]."' title=\"".$files[$j]."\" style=\"text-decoration:none\" href=\"bilder/".$files[$j]."\">".hp_thumb("bilder",$files[$j],200)."</a>
</noscript>
</td>";
if($count%$pics_in_row==0){$out .= "</tr>\n<tr>\n";}
$count++;
}
if($count%$pics_in_row!=0){$out .= "</tr>\n";}
$out .= "<tr><td align='right' colspan=3><br />\n".$wahl1."<hr />\n".$wahl2."\n";
$out .= "</td></tr></table>\n";
return $out;
}

function hp_pic_pod(){
global $funccount;
$funccount++;
$handle=opendir("./bilder");
                while ($file = readdir ($handle)) {
                    if ($file != "." && $file != ".." && $file != "CVS" && $file != "thumb" && $file != "klein" && $file!="Thumbs.db") {
                       $files[] = $file;
                    }
                }
                closedir($handle);
$pod_id = rand(0,sizeof($files)-1);



return "<a style='cursor: move' title=\"".$files[$pod_id]."\" href=\"javascript:void(window.open('show.php?action=view&file=bilder/".$files[$pod_id]."','Bild".$j."','".get_img_size("bilder/".$files[$pod_id],1).",SCROLLBARS=yes,RESIZABLE=yes,TOOLBAR=NO'))\" onMouseOver=\" self.status = '".$files[$pod_id]." anzeigen lassen'; return true\" onMouseOut=\"self.status=''; return true\" style=\"text-decoration:none\" >".hp_thumb("bilder",$files[$pod_id],200,140)."</a>
<noscript>
<a style='cursor: move' target='_BILD".$files[$pod_id]."' title=\"".$files[$pod_id]."\" style=\"text-decoration:none\" href=\"bilder/".$files[$pod_id]."\">".hp_thumb("bilder",$files[$pod_id],200,140)."<small><br />\n</small>".$files[$pod_id]."".get_img_size("bilder/".$files[$pod_id])."</a>
</noscript>";
}

function hp_jn($wert){
global $funccount;
$funccount++;
if ($wert=="1"){return "JA";}
else {return "NEIN";}
}

function hp_jz($month){
global $funccount;
$funccount++;
                switch($month){
                case "1":
                return "Fr&uuml;hling";
                break;
                case "2":
                return "Sommer";
                break;
                case "3":
                return "Herbst";
                break;
                case "4":
                return "Winter";
                break;
                case "5":
                return "Fr&uuml;hling";
                break;
                case "6":
                return "Sommer";
                break;
                case "7":
                return "Herbst";
                break;
                case "8":
                return "Winter";
                break;
                case "9":
                return "Fr&uuml;hling";
                break;
                case "10":
                return "Sommer";
                break;
                case "11":
                return "Herbst";
                break;
                case "12":
                return "Winter";
                break;
                }
}
function hp_time($time = 0){
global $funccount;
$funccount++;
         if(!$time){$time = time();}
         $year = date("Y",$time) - 2003;
         $month = date("n",$time);
         $secs = date("z",$time) * 24 * 60 * 60;
         $count = (($secs - $secs%10512000)/10512000) + 1;
         $year = $count + 3 * $year + 66;

         if($month<5){$count += 1;$jz = hp_jz($month,1);}
         elseif($month<9){$count += 2;$jz = hp_jz($month,2);}
         else{$count += 3;$jz = hp_jz($month,3);}
         return $jz." im Jahre ".$year.", ".date("j",$time).". Tag, ".date("H:i",$time);
}

function hp_jn_drop($name="jndrop",$wert){
global $funccount;
$funccount++;
$out.=" <select name=\"".$name."\">\n";
                switch($wert){
                case "1":
                $out.=" <option selected value=1>Ja</option>\n<option value=2>Nein</option> ";
                break;
                default:
                $out.=" <option value=2>Ja</option>\n<option selected value=2>Nein</option> ";
                }
$out.="</select>\n";
}

function hp_target($ziel){
global $funccount;
$funccount++;
switch($ziel)
        {
        case"_top":
        return "Hauptseite";
        break;
        default:
        return "Window";
        }
}


function hp_gettemplate($template){
global $funccount,$templcount;
$funccount++;
$templcount++;
        $templatefolder = "templates/";
        return str_replace("\"","\\\"",implode("",file("templates/".$template.".htm")));
}


//##############################################################################
function hp_getgroup($id){
global $config,$db,$funccount;
$funccount++;
require($config);
$result = $db->query("SELECT title FROM bb".$forumnr."_groups WHERE groupid='".$id."'");
                while ($row = $db->fetch_array($result))
                {
                $out = $row["title"];
                }
$db -> free_result($result);
return $out;
}

function hp_checkexist($cat,$wert,$dbtable){
global $config,$db,$funccount;
$funccount++;
require($config);
$exist = 0;
$result = $db->query("SELECT ".$cat." FROM ".$dbtable." ");
                while ($row = $db->fetch_array($result))
                {
                if($wert == $row[$cat])
                $exist =1;
                }
$db -> free_result($result);
return $exist;
}

function hp_sqlquery($query,$db){
global $config,$db,$funccount;
$funccount++;
require($config);
$result = $db->query($query);
if($result){return "1";}else{return "0";}
$db -> free_result($result);
}

function hp_sqlinsertlastid(){
global $config,$db,$funccount;
$funccount++;
require($config);
$id = $db->insert_id();
if($id){return $id;}else{return "";}
$db -> free_result($result);
}

//##############################################################################
//## NEUE CONTENT VERWALTUNG ###################################################
function hp_show_content($c_id = "", $t_id = "", $wbbuserdata, $stylepack ){
global $config,$db,$parse,$funccount;
$funccount++;
                require($config);
                if($c_id != ""){
                                $result = $db->query("SELECT * FROM bb".$forumnr."_posts WHERE postid = '".$c_id."'");
                                }
                else{
                                $result = $db->query("SELECT * FROM bb".$forumnr."_posts WHERE threadid = '".$t_id."' LIMIT 0,1");
                                }
                while ($row = $db->fetch_array($result)){
                                if($row["editor"] != ""){
                                $row["posttime"] = "am ".date("d.m.y, H:i",$row["edittime"]);
                                $row["username"] = $row["editor"];
                                }
                                else{
                                $row["posttime"] = "am ".date("d.m.y, H:i",$row["posttime"]);
                                }
                                $row["message"] = $parse->doparse($row["message"],1,1,1,1);
                                $row["message"] = hp_formatout($stylepack,$row["message"]);
                                $row["posttopic"] = "<h3>".$parse->textwrap($row["posttopic"],30)."</h3>";
                                eval("\$out = \"".hp_gettemplate("hp_content")."\";");
                }
                $db -> free_result($result);
                return $out;
}

function hp_show_sitemap($p_id,$wbbuserdata, $stylepack){
                $i = 0;
global $config,$db,$funccount;
$funccount++;
                require($config);
                $result = $db->query("SELECT * FROM `bb".$forumnr."_threads` t, `".$hp_options['db_links']."` l WHERE boardid = '".$contentforum."' AND l.threadid = t.threadid GROUP BY t.topic ORDER BY t.rank ASC, t.topic ASC");
                $num = $db->num_rows($result);
                $num = round($num/2,0);
                $out .= "<table width='96%'><tr><td valign='top'>\n";
                while ($row = $db->fetch_array($result)){
                             $nodes = $db->query("SELECT * FROM `bb".$forumnr."_posts` WHERE  posttopic!='' AND threadid = '".$row['threadid']."' ");
                             if($db->num_rows($nodes) > 0)
                             $out .= "\n<br />\n".$row['topic']."<!--".$row['threadid']."--><hr width=200 noshade/>\n";
                             while ($row2 = $db->fetch_array($nodes)){
                             $out .= "\n&raquo; <a href='index.php?action=content&c_id=".$row2['postid']."&t_id=".$row['threadid']."&p_id=".$p_id."'>".$row2['posttopic']."</a><br />\n\n";
                             }
                             $db->free_result($nodes);
                             $nodes = $db->query("SELECT * FROM `".$db_links."` WHERE threadid = '".$row['threadid']."' ");
                             if($db->num_rows($nodes) > 0)
                             while ($row2 = $db->fetch_array($nodes) AND $row2['linktitel'] != "back"){
                             $linkarray = split(":",$row2['linkcontent']);
                             if(sizeof($linkarray)>2){
                                        $out .= "\n&raquo; <a href='index.php?action=content&c_id=".$linkarray[0]."&p_id=".$linkarray[2]."'>".$row2['linktitel']."</a><br />\n\n";
                                        }
                                        else{
                                        $out .= "\n&raquo; <a href='".$linkarray[0]."'>".$row2['linktitel']."</a><br />\n\n";
                                        }
                        }
                        $db->free_result($nodes);
                     $i++;
                     if($i == $num){
                     $out .= "\n\n</td><td width=10></td><td valign='top'>\n\n";
                     }
                }
                $db -> free_result($result);
                $out .="</td></tr></table>\n";
return $out;
}


function hp_show_nav($c_id, $t_id, $p_id, $wbbuserdata, $stylepack){
                $navs = array();
global $config,$db,$parse,$funccount;
$funccount++;
                require($config);

                if($c_id != ""){
                $result = $db->query("SELECT threadid FROM `bb".$forumnr."_posts` WHERE postid = '".$c_id."' ");
                $content = $db->fetch_array($result);
                $db -> free_result($result);
                                }
                else{
                                $content['threadid'] = $t_id;
                                }
                if($t_id == ""){
                    $db->query("UPDATE `bb".$forumnr."_threads` SET views=views+1 WHERE threadid = '".$content['threadid']."' ");
                }
                $result = $db->query("SELECT * FROM `bb".$forumnr."_threads` WHERE threadid = '".$content['threadid']."' ");
                $thread = $db->fetch_array($result);
                $db -> free_result($result);

                $result = $db->query("SELECT * FROM `bb".$forumnr."_posts` WHERE posttopic!='' AND threadid = '".$thread['threadid']."' ORDER BY post_rank ASC, posttopic ASC");
                if($db->num_rows($result) > 0){
                                $navcaption = $thread['topic']." Inhalt: ";
                                $navcontent = "<td>\n";
                                while ($row = $db->fetch_array($result)){
                                if($row['postid'] == $c_id){
                                                $navs[$i]['rank']= $row['post_rank'];
                                                $navs[$i]['name']= $row['posttopic'];
                                                $navs[$i]['link']= "index.php?action=content&c_id=".$row['postid']."&t_id=".$thread['threadid']."&p_id=".$p_id;
                                                $navs[$i]['titel']= $row['posttopic']." anzeigen";
                                                $navs[$i]['akt']= 1;
                                                }
                                else{
                                                $navs[$i]['rank']= $row['post_rank'];
                                                $navs[$i]['name']= $row['posttopic'];
                                                $navs[$i]['link']= "index.php?action=content&c_id=".$row['postid']."&t_id=".$thread['threadid']."&p_id=".$p_id;
                                                $navs[$i]['titel']= $row['posttopic']." anzeigen";
                                                $navs[$i]['akt']= 0;
                                                }
                                $i++;
                                }

                }

                $db -> free_result($result);

                $result = $db->query("SELECT * FROM `".$db_links."` WHERE threadid = '".$thread['threadid']."' ORDER BY linktitel ASC");
                if(($db->num_rows($result) > 0) OR ($p_id !="")){


                                while ($row = $db->fetch_array($result)){
                                $linkarray = split(":",$row['linkcontent']);
                                   if($row['linktitel'] == "back"){
                                               if(sizeof($linkarray)>2){
                                                                $navcontent .= "<b>&laquo; <a title='Ebene nach oben' href='index.php?action=content&c_id=".$linkarray[0]."&p_id=".$linkarray[2]."'>".$row['linktitel']."</a></b><hr />\n";
                                               }
                                               else{
                                                                $navcontent .= "<b>&laquo; <a title='Ebene nach oben' href='".$linkarray[0]."'>".$row['linktitel']."</a></b><hr />\n";
                                               }
                                   }
                                   else{

                                                if(sizeof($linkarray)>2){
                                                                $navs[$i]['rank']= $row['link_rank'];
                                                                $navs[$i]['name']= $row['linktitel'];
                                                                $navs[$i]['link']= "index.php?action=content&c_id=".$linkarray[0]."&p_id=".$linkarray[2];
                                                                $navs[$i]['titel']= "'".$row['linktitel']."' &ouml;ffnen";
                                                                $navs[$i]['akt']= 0;
                                                }
                                                else{
                                                                $navs[$i]['rank']= $row['link_rank'];
                                                                $navs[$i]['name']= $row['linktitel'];
                                                                $navs[$i]['link']= $linkarray[0];
                                                                $navs[$i]['titel']= "'".$row['linktitel']."' &ouml;ffnen";
                                                                $navs[$i]['akt']= 0;
                                                }
                                   $i++;
                                   }
                                }
                                asort($navs);
                                reset($navs);
                                foreach($navs as $part){
                                         if($part['akt'] == 1){
                                         $navcontent .= "<big>&raquo;</big> <small><a title='".$part['titel']."' href='".$part['link']."'>".$part['name']."</a></small><br />\n\n";
                                         }
                                         else{
                                         $navcontent .= "<small><a title='".$part['titel']."' href='".$part['link']."'>".$part['name']."</a></small><br />\n\n";
                                         }
                                }

                                $navcontent .= "</td>\n";
				eval("\$fo = \"".hp_gettemplate("frameo")."\";");
				eval("\$fu = \"".hp_gettemplate("frameu")."\";");
                eval("\$out .= \"".hp_gettemplate("hp_nav")."\";");
                }
                $db -> free_result($result);
                return $out;
                }




function hp_getnavname($navid){
global $config,$db,$funccount;
$funccount++;
require($config);
$result = $db->query("SELECT id,navheader FROM ".$dbnavtitle." WHERE id='".$navid."'");
while ($row = $db->fetch_array($result))
{
$out=$row["navheader"];
}
$db -> free_result($result);
return $out;
}



//##############################################################################
//gibt einen $wert aus $db aus, wenn $cat = $value ist
function hp_getby($tablename,$wert,$cat,$value){
global $config,$db,$funccount;
$funccount++;
require($config);
$result = $db->unbuffered_query("SELECT ".$wert." FROM ".$tablename." WHERE ".$cat." = '".$value."'");
while ($row = $db->fetch_array($result))
                               {
                               $wert=$row[$wert];
                               }
$db -> free_result($result);
return $wert;
}

function hp_stylepackfix($stylepack){
global $funccount;
$funccount++;
    foreach ($stylepack as $key => $part){
    $stylepack[$key] = str_replace("images/","forum/images/",$part);
    }
return $stylepack;
}

function hp_formatout($stylepack,$string){
global $funccount;
$funccount++;
$string = str_replace("{imagefolder}",$stylepack["imagefolder"],$string);
return $string;
}


function hp_sqlstats(){
global $pagestarttime, $querytimer, $query_count,$funccount,$templcount;
$funccount++;
$totaltime = microtime_past($pagestarttime,microtime());
return "Seite wurde in <b>".$totaltime."s</b> aufgebaut :: <b>$query_count</b> Datenbankquerys wurden in <b>".$querytimer."</b>s erledigt :: mit <b>".$funccount."</b> Funktionen & <b>".$templcount."</b> Templates :: ".hp_compressed_output()."\n";
}

function hp_ircstats(){
/*$irc = &new Net_SmartIRC();
$irc->startBenchmark();
$irc->setDebug(SMARTIRC_DEBUG_ALL);
$irc->setUseSockets(TRUE);
$irc->setBenchmark(TRUE);
$irc->connect('irc.spielviel.de', 6667);
$irc->login('Net_SmartIRC', 'Net_SmartIRC Client '.SMARTIRC_VERSION.' (example2.php)', 0, 'Net_SmartIRC');
$irc->getList('#noomi');
$resultar = $irc->listenFor(SMARTIRC_TYPE_LIST);
$irc->disconnect();
$irc->stopBenchmark();

if (is_array($resultar)) {
    $resultex = explode(' ', $resultar[0]);
    $count = $resultex[1];*/
    $count = "X";
    $out ="<small>".$count." Users in <a href='irc://irc2.spielviel.de/noomi'>#noomi</a></small>\n";
#} else {
#    $out ="<b>An error occured<b>\n";
#}
return $out;
}

function hp_getprofillink($username,$userid,$sid=""){
global $funccount;
$funccount++;
      $out .= "<noscript><a target='_USRPROFIL'  href='forum/profile.php?userid=".$userid."&sid=".$sid."'>".$username."</noscript>\n";
      $out .= "<a href=\"javascript:void(0);\" onClick=\"window.open('forum/profile.php?userid=".$userid."&sid=".$sid."','_USRPROFIL','width=600,height=500,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\">".$username."</a>\n";

return $out;
}

function show_useronline($wbbuserdata){
global $config,$db,$funccount;
$funccount++;
require($config);

if($wbbuserdata['userid'] !=0){
                require("./forum/acp/lib/class_useronline.php");
                $activtime=time()-60*$useronlinetimeout;
                $online = new useronline($wbbuserdata['canuseacp'],$modids,$smodids,$adminids,$wbbuserdata['buddylist']);
                $result = $db->query("SELECT DISTINCT bb".$forumnr."_sessions.userid, username, groupid, invisible FROM bb".$forumnr."_sessions LEFT JOIN bb".$forumnr."_users USING (userid) WHERE bb".$forumnr."_sessions.userid > 0 AND bb".$forumnr."_sessions.lastactivity > '$activtime' AND boardid = '$boardid' ORDER BY username ASC");
                while($row = $db->fetch_array($result)) $online->user($row['userid'],$row['username'],$row['groupid'],$row['invisible']);
                //$online -> user($wbbuserdata['userid'], $wbbuserdata['username'], $wbbuserdata['groupid'], $wbbuserdata['invisible']);
                $string = $online->useronlinebit;
                        if($string != ""){
                           $string = str_replace("profile.php","forum/profile.php",$string);
                           return "<small>User online: ".$string."</small>";
                        }
}
}



function hp_get_attachment($postid,$sid){
global $config,$db,$funccount;
$funccount++;
require($config);
$result = $db->query("SELECT attachmentid, attachmentextension, attachmentname, attachmentsize FROM `bb".$forumnr."_attachments` WHERE postid = '".$postid."'");
$row = $db->fetch_array($result);
$nb = $db -> num_rows($result);
$db -> free_result($statusresult);
$row['attachmentsize'] = round($row['attachmentsize']/1024,2);
switch(strtolower($row['attachmentextension'])){
case"jpg":
      $out .= "<noscript><a target='_Attachment' style=\"text-decoration:none\" href='show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."'><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a></noscript>\n";
      $out .= "<a style=\"text-decoration:none\" href=\"javascript:void(0);\" onClick=\"window.open('show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."','Bild_BIG','width=700,height=500,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\"><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a>\n";
break;
case"jpeg":
      $out .= "<noscript><a target='_Attachment' style=\"text-decoration:none\" href='show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."'><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a></noscript>\n";
      $out .= "<a style=\"text-decoration:none\" href=\"javascript:void(0);\" onClick=\"window.open('show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."','Bild_BIG','width=700,height=500,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\"><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a>\n";
break;
case"gif":
      $out .= "<noscript><a target='_Attachment' style=\"text-decoration:none\" href='show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."'><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a></noscript>\n";
      $out .= "<a style=\"text-decoration:none\" href=\"javascript:void(0);\" onClick=\"window.open('show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."','Bild_BIG','width=700,height=500,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\"><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a>\n";
break;
case"png":
      $out .= "<noscript><a target='_Attachment' style=\"text-decoration:none\" href='show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."'><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a></noscript>\n";
      $out .= "<a style=\"text-decoration:none\" href=\"javascript:void(0);\" onClick=\"window.open('show.php?action=view&file=forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."','Bild_BIG','width=700,height=500,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\"><img width=100 border=0 src='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."' /><br />".$row['attachementname']." (".$row['attachmentsize']." KB)</a>\n";
break;
default:
      $out .= "<a href='forum/attachment.php?attachmentid=".$row['attachmentid']."&sid=".$sid."'>".attachementname." (".$row['attachmentsize']." KB)</a>";
}
//      if(strtolower($row['attachmentextension']) == "jpg" || )
        if($nb > 0){
            return "\n\n<hr /><table><tr><td valign='top'><font size='1' face='verdana,arial'>Anhang:</font></td><td>".$out."</td></tr></table>\n\n";
        }
}

function hp_show_pms(){
global $hp_options, $db, $funccount, $wbbuserdata;
	$funccount++;
	$sql = "SELECT * FROM bb".$hp_options['forumnr']."_privatemessage WHERE recipientid = '".$wbbuserdata['userid']."' AND view = '0' ";
	$result = $db-> query($sql);
	$num = $db->num_rows($result);
	if($num > 0)
	{
		if($num > 1)
		{
			$label = $num." neue Nachrichten\n";
		} else {
			$label = "eine neue Nachricht\n";
		}
		$out = "<tr><td>
			<a href=\"javascript:void(0);\" onClick=\"window.open('forum/pms.php','PMs','width=725,height=525,resizable=no,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\">
				<small><b><blink>".$label."</blink></b></small>
			</a>
			<noscript>
			<a target=\"PMs\" href=\"forum/pms.php\">
				<small><b><blink>".$label."</blink></b></small>
			</a>
			</noscript>
		</td></tr>\n";		
	} else {
		$out = "<tr><td><small>keine neuen Nachrichten</small></td></tr>\n";
	}
return $out;
}

function show_devlist(){
global $config,$db,$funccount;
$funccount++;
require($config);
$count = 0;
$ges_status = 0;
                $result = $db->query("SELECT threadid,topic,lastposttime FROM `bb".$forumnr."_threads` WHERE boardid = '".$devforum."' ORDER BY `lastposttime` DESC");
                while ($row = $db->fetch_array($result)){
                                       $statusresult = $db->query("SELECT posttopic, username, posttime, message FROM `bb".$forumnr."_posts` WHERE threadid = '".$row["threadid"]."' ORDER BY `posttime` DESC  LIMIT 0 , 1 ");
                                       $status = $db->fetch_row($statusresult);
                                       $db -> free_result($statusresult);
                                       if($status[0] !='100%'){
                                       $out.= "<tr><td width='150'><small><br />\n".$row["topic"]."</small></td></tr>";
                                       $out.= "<tr><td align='center' width='150'>".show_statusbar($status[0],$status[1],$status[2],$status[3],130)."</td></tr>";
                                       }
                                       //echo $count.":".intval($status[0])."<br />\n";
                                       $ges_status += intval($status[0]);
                                       $count++;
                }
$head.= "<tr><td width='150'><small><br />\nGesamt:</small></td></tr>";
$head.= "<tr><td align='center' width='150'>".show_statusbar(round($ges_status/$count,0)."%","SYSTEM",time(),"",130)."<hr /></td></tr>";

return $head.$out;
}



function show_statusbar($status,$poster,$time,$statement,$width=400){
global $funccount;
$funccount++;
if(strlen($status) < 4){
                                if(intval($status) < 33){
                                $bgcolor = "red";$l = 0;
                                }
                                elseif(intval($status) < 50){
                                $bgcolor = "green";$l = 0;
                                }
                                elseif(intval($status) < 75){
                                $bgcolor = "yellowgreen";$l = 1;
                                }
                                else{
                                $bgcolor = "gold";$l = 1;
                                }
                $rechts = 100 - $status;
                if($statement){$title = $poster." schrieb am ".date("d.m.y, H:i",$time).":\n ".$statement;}else{$title="";}
                if($l){$l = $status;$r = "&nbsp;";}else{$l = "&nbsp;"; $r = $status;}
return "<table title='".$title."' cellspacing='0' cellpadding='0' style='border: 1px solid black' width=".$width.">
<tr>
<td style='font-size: 11px;' align='center' bgcolor='".$bgcolor."' width='".$status."'>".$l."</td>
<td style='font-size: 11px;' align='center' width='".$rechts."'>".$r."</td>
</tr>
</table>";
}
else {return "N/A";}
}

function hp_show_lastposts($wbbuserdata,$stylepack,$sid){
global $config,$db,$parse,$funccount,$hp_options;
$funccount++;
require($config);

$result = $db->query("SELECT t.threadid, t.lastposttime, t.lastposterid, t.lastposter, t.topic FROM bb".$forumnr."_threads t, bb".$forumnr."_boards b WHERE b.boardid = t.boardid AND b.invisible!='1' AND (b.boardid != '".$hp_options['bugforum']."' AND b.boardid != '".$hp_options['newsforum']."') ORDER BY t.lastposttime DESC LIMIT 0,5");
$out .= "<tr><td>\n<table>\n";
while ($row = $db->fetch_array($result)){

        if(isset($_COOKIE['threadvisit'])) $threadvisit=decode_cookie($_COOKIE['threadvisit']);
        else $threadvisit=array();

        if($wbbuserdata['lastvisit']<$row['lastposttime'] && $threadvisit[$row['threadid']]<$row['lastposttime']){
        $icon = "<img height=\"30\" title='Neuer Beitrag' border=0 src='".$stylepack['imagefolder']."/on.gif' />";
        }
        else{
        $icon = "<img height=\"30\" title='Kein neuer Beitrag' border=0 src='".$stylepack['imagefolder']."/off.gif' />";
        }

        $post = $db->query("SELECT postid FROM bb".$forumnr."_posts WHERE threadid = '".$row['threadid']."' ORDER BY posttime DESC LIMIT 0,1");
        $row2 = $db->fetch_array($post);
        $db -> free_result($post);
        $row["lastposttime"] = "<span style='font-size: 10px;'>".date("d.m.y, H:i",$row["lastposttime"])."</span>";
        $row["topic"] = $parse->textwrap($row['topic'],30);
        $out .= "<tr><td valign='top'><a href='javascript:void(0);' onClick=\"window.open('index.php?action=entryshow&threadid=".$row['threadid']."#post".$row2["postid"]."','".$row['threadid']."','width=550,height=450,resizable=no,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,left=50,top=50')\">".$icon."</a></td><td><small>".$row["lastposttime"]."<br />von <a href='forum/profile.php?userid=".$row["lastposterid"]."&sid=".$sid."'>".$row["lastposter"]."</a>: <br />\n\n<b><a title='".$row["topic"]."' href='forum/thread.php?postid=".$row2["postid"]."&sid=".$sid."#post".$row2["postid"]."'>".$row["topic"]."</a></b><br />\n</small></td></tr>\n";
}
$db -> free_result($result);
$out .= "</table>\n</td></tr>\n";
return $out;
}


function hp_bugshow($wbbuserdata,$stylepack){
global $config,$db,$funccount;
$funccount++;
require($config);
$t_count = 0;
$result = $db->query("SELECT * FROM bb".$forumnr."_threads WHERE boardid='".$bugforum."' AND closed != '1' ORDER BY starttime DESC LIMIT 0,5");
$nb = $db -> num_rows($result);
if($nb > 0){
           while ($row = $db->fetch_array($result)){
                   $row["starttime"] = strftime("%A, %d. %B %Y",$row["starttime"]);
                   $row["starter"] = $row["starter"]."\n";
                   $row["lastposttime"] = strftime("%A, %d. %B %Y",$row["lastposttime"]);
                   eval("\$out.= \"".hp_gettemplate("hp_bugs")."\";");
                   $t_count++;
                   }
}
else{
$out .= " <tr><td><small>keine Bugs gemeldet</small></td></tr> ";
}
$db -> free_result($result);
return $out;
}

function hp_newsshow($wbbuserdata,$stylepack,$sid,$start="",$hilight=""){
global $config,$db,$parse,$funccount;
$funccount++;
require($config);
@setlocale("LC_TIME", "de_DE");

if ($start==""){$start="0";}

$result = $db->query("SELECT message FROM bb".$forumnr."_posts p,bb".$forumnr."_threads t WHERE t.boardid='".$newsforum."' AND p.threadid=t.threadid AND p.posttime=t.starttime");
$nb = $db -> num_rows($result);
$db -> free_result($result);
$result = $db->query("SELECT p.threadid,p.userid,p.username,p.posttime,p.posttopic,p.message FROM bb".$forumnr."_posts p,bb".$forumnr."_threads t WHERE t.boardid='".$newsforum."' AND p.threadid=t.threadid AND p.posttime=t.starttime ORDER BY t.starttime DESC LIMIT ".$start.",5");

$wert="<table width='90%'>\n";

while ($row = $db->fetch_array($result)){
                               $email=hp_getby("bb".$forumnr."_users","email","userid",$row["userid"]);
                               $time="am ".date("d.m.y, H:i",$row["posttime"]);

                               //$message = $row['message'];
                               //$topic = $row['posttopic'];
                               $newsparse = new parse(0,75,1,1,$wbbuserdata['showimages'],$hilight,1);
                               $message = $parse->doparse($row['message'],1,1,1,1);
                               $message = hp_formatout($stylepack,$message);
                               $topic = $parse->textwrap($row['posttopic'],30);
                               $user = hp_getprofillink($row["username"],$row["userid"],$sid);
                               $threadid=$row["threadid"];
                               eval("\$wert.= \"".hp_gettemplate("hp_news")."\";");
                               }

//$wertunten="</td></tr><tr><td valign=\"middle\" align=\"center\">\n";
$zahl="0";
for ($i=0;$i<$nb;$i++)
{
	if($i%5==0)
	{
		$page=$zahl*5;
		if($page>0 && $page%100=="0")
		{
			$ende="<br />\n";
		}

		if ($page==$start)
		{
			$zahls = "<big title='aktuelle Seite'><b>[".++$zahl."]</b></big>\n";
		}
		else
		{
			$zahls="<a title='zur ".++$zahl.". Seite' href=\"index.php?action=news&start=".$page."\"><small>".$zahl."</small></a>\n";
		}
	
		$wertunten.="&nbsp;".$zahls."&nbsp;".$ende;
	}
}
$db -> free_result($result);
$wert .= "</td></tr>

<tr><td align='right'>

<table cellpadding='0' cellspacing='0'>
<tr id='tabletitle' bgcolor='".$stylepack["tablecolora"]."'>
<td>Seite &raquo; ".$wertunten."</td></tr>
</table>
";
return $wert."</td></tr></table>";
}

function hp_eintragshow($wbbuserdata,$id,$stylepack,$sid,$hilight=""){
global $config,$db,$parse,$funccount;
$funccount++;
require($config);
@setlocale("LC_TIME", "de_DE");


$result = $db->query("SELECT threadid,userid,username,posttime,posttopic,message,postid FROM bb".$forumnr."_posts WHERE threadid='".$id."' ORDER BY posttime ASC");
while ($row = $db->fetch_array($result)){
                               $newsparse = new parse(0,75,1,1,$wbbuserdata['showimages'],$hilight,1);
                               $message = $parse->doparse($row['message'],1,1,1,1);
                               $entry['message'] = hp_formatout($stylepack,$message);
                               $entry['topic'] = $parse->textwrap($row['posttopic'],30);
                               $entry['attachment'] = hp_get_attachment($row['postid'],$sid);
                               $entry['profil'] = hp_getprofillink($row["username"],$row["userid"],$sid);
                               $entry['date'] = date("d.m.y, H:i",$row["posttime"]);
                               /*$wert .="<br />\n<table width='90%' cellpadding='3' cellspacing='0' style='border: 1px solid black' align='center' valign='center'>";
                               $wert .="<tr id='tablecat' bgcolor='".$stylepack[tabletitlecolor]."'><td> ".$stylepack[smallfont]." color='".$stylepack[fontcolorthird]."'><a name='post".$row["postid"]."'></a><b>".$entry['profil']." schrieb am ".$entry['date'].": ".$entry['topic']."</b></font></td></tr>";
                               $wert .="<tr><td id='tablea' bgcolor='".$stylepack[tablecolora]."'><font size='1' face='verdana,arial'>".$entry['message']."</font></td></tr>";
                               $wert .="<tr><td id='tablea' bgcolor='".$stylepack[tablecolora]."'>".$entry['attachment']."</td></tr>";
                               $wert.="</table><br />\n";*/
                               eval("\$entrys.= \"".hp_gettemplate("hp_entryshowbit")."\";");
                               }


if($wbbuserdata['userid']){
$postheader ="RE: ".$entry['topic'];
eval("\$shortpost = \"".hp_gettemplate("hp_shortpost")."\";");
}
else{$shortpost ="<input type=\"Submit\" value=\"schliessen\" onclick=\"javascript: self.close()\">";}
eval("\$wert = \"".hp_gettemplate("hp_entryshow")."\";");
return $wert;
$db -> free_result($result);
}


function db_insert($db_name, $cat, $val, $catarray, $valuearray, $laden = 0){
global $config, $db, $funccount;
$funccount++;
$i = 0;
require($config);
$result = $db->query("SELECT ".$cat.",item_name FROM ".$db_name." WHERE ".$cat." = '".$val."' ");
  if($db -> num_rows($result) > 0){
      //Update
      $row = $db->fetch_array($result);
      foreach($catarray as $part){
        $query .= $part." = '".$valuearray[$i]."', ";
        $i++;
      }
      if($laden){
      $query = substr($query,0,-2);
      $abfrage = "UPDATE `".$db_name."` SET ".$query." WHERE ".$cat." = '".$val."' ";  $db->query($abfrage);
      $db->query($abfrage);
      }
  if($row['item_name'] == 0){$row['item_name'] = "N/A";}
  $out = $row['item_name'];
  }
  else{
      //insert
      foreach($catarray as $part){
        $cat_query .= "`".$part."`, ";
        $var_query .= "'".$valuearray[$i]."', ";
        $out =  "insert ".$valuearray[$i];
        $i++;
      }
  $query = " (".substr($cat_query,0,-2).") VALUES (".substr($var_query,0,-2).")";
  $abfrage = "INSERT INTO `".$db_name."` ".$query;
  $db->query($abfrage);
  }

$db -> free_result($result);
Return $out;
}
?>