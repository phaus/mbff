<?php
$layerarray = array('',
'rechte Hand: erste Waffe/Werkzeug',
'linke Hand: Schild/Zweih�ndig',
'Fussbekleidung: Schuhe/R�stung',
'Beinschoner',
'K�rperbekleidung: Kleidung/(Frauen-) R�stung',
'Kopfbedeckung: Kleidung/R�stung',
'Handschuhe/R�stung',
'Ringe',
'N/A',
'Nacken: Kleidung/R�stung',
'Haare',
'Taille:',
'K�rper I: R�stung',
'Hand: Armband',
'N/A',
'Bart u.a.',
'K�rper II: Wappenrock/Tunika/Schurz)',
'Ohrringe',
'Armschutz',
'Umhang',
'BackPack',
'K�rper III: Robe',
'Beine I: Rock/Kilt',
'Beine II: R�stung',
'Reittier (Pferd, Ostard, usw.)',
'NPC Buy Restock Container',
'NPC Buy No Restock Container',
'NPC Sell Container',
'Bank Box');

function get_layerdrop($layer = 1){
global $db, $layerarray, $hp_options;
    $sql = "SELECT * FROM ".$hp_options['db_sys_items']." WHERE item_layer = '".$layer."'";
    $result = $db->query($sql);
    $out.="\n<select class=\"input\" size=\"1\" name=\"charlayer[".$layer."]\">\n";
    $out.="<option value=\"\" >".$layerarray[$layer]."</option>\n";
    $out.="<option value=\"-1\" ><--nichts--></option>\n";
    while($row = $db->fetch_array($result))
    {
           $out.="<option value=\"".$row["item_id"]."\" >(".$row["item_value"]." t, ".$row["item_weight"]." st) ".$row["item_name"]."</option>\n";
    }
    $out.="</select>\n";
return $out;
}


function show_chars(){
global $hp_options, $db, $wbbuserdata, $funccount;
  $funccount++;
  $p_x = 10;
  $p_y = 120;
  $out .= "<table height=\"90%\" width=\"90%\">\n";
  $out .= "<tr>\n";
  $sql = "SELECT * FROM ".$hp_options['db_sys_chars']." WHERE char_account_id = '".$wbbuserdata['userid']."'";
  $result = $db-> query($sql);
  while($row = $db->fetch_array($result)){

      $out.= "<td style=\" ONMOUSEOVER=\"this.bgColor = \"#66F4B6\"\" ONMOUSEOUT=\"this.bgColor = \"\";\" onclick=\"location=\"account.php?action=chars&amp;subaction=charview&amp;char_id=".$row['char_id']."\"\"\">".get_char($row, $p_x, $p_y)."</td>\n";
      $p_x += 240;
  }

  $sql = "SELECT * FROM ".$hp_options['db_sys_chars']." WHERE char_account_id = '".$wbbuserdata['userid']."' AND char_type='1'";
  $result = $db-> query($sql);
  $out .= "<td valign=\"top\" align=\"right\">\n";
  if($db -> num_rows($result) < $hp_options['normal_char_limit']){
      $out .= "<b><big>&raquo; <a href=\"chargen.php\">Charakter erstellen</a></big></b>\n";
  } else {
  }
  $db -> free_result($result);
  $out .= "<br /><br />".char_legende()."</td>\n";
  $out .= "</tr>\n";
  $out .= "</table>\n";
  $db -> free_result($result);
return $out;
}

function char_legende(){
global $funccount;
  $funccount++;
  $out.= "
  <table rules=\"rows\" frame=\"box\" border=\"1\" cellspacing=\"1\" cellpadding=\"4\">
  <tr><th colspan=\"2\">Legende:</th></tr>
  <tr><td colspan=\"2\"><small><i>Der Charhintergrund<br /> ist nach folgenden<br /> Angaben gef&auml;rbt:</i></small></td></tr>
  <tr><td width=\"20\" height=\"20\" bgcolor=\"black\"></td><td>Spieler</td></tr>
  <tr><td width=\"20\" height=\"20\" bgcolor=\"grey\"></td><td>Support</td></tr>
  <tr><td width=\"20\" height=\"20\" bgcolor=\"blue\"></td><td>Dev</td></tr>
  <tr><td width=\"20\" height=\"20\" bgcolor=\"gold\"></td><td>Admin</td></tr>
  </table>
  ";
return $out;
}

function char_skills($char){
global $hp_options, $db, $wbbuserdata, $funccount;
$funccount++;
require("rpg_math.php");
return skills($char);
}

function char_attr($char_raceid = "-1"){
require("attri_blank_sets.php");
global $hp_options, $c_id, $db, $wbbuserdata, $funccount;
	$funccount++;
	
	// Depotangaben:
	$depotname ="Pool";
	$depotvalue ="36";
	$jstpl1="";    // 1. Liste f�r Javescript
	$jstpl2="";    // 2. Liste f�r Javascript
	$form ="attribute"; // Name des Formulars
	$out .= "<form action=\"chargen.php?step=3\" method=\"post\" name=\"".$form."\">\n";
	$out .= $c_id;	
	$out .= "<table width=\"90%\">\n";
	$out .= "<tr><th colspan=\"5\"><h3>Die Attribute:</h3><hr /></th></tr></tr>\n";
	foreach($attr as $key => $part){
		   $title = $part["name"];  // Name
		   $name  = $key;           // Schl�sselname (z.b. stat_intel)
		   $min   = $part["min"];   // Minimaler Wert
		   $max   = $part["max"];   // Maximaler Wert
		   $value = $part["set"];   // Wert aktuell
		   eval("\$jstpl1 .= \" ".gettemplate("hp_chargen_jstpl1")."\";");
		   eval("\$jstpl2 .= \" ".gettemplate("hp_chargen_jstpl2")."\";");
		   eval("\$out .= \"".gettemplate("hp_chargen_pm")."\";");
	}
	$out .= "<tr><th colspan=\"5\"><hr /></th></tr></tr>\n";
	$out .= "</table>\n";
	//erstelle Depot
	eval("\$out .= \"".gettemplate("hp_chargen_depot")."\";");
	//echo $out."\n";;
return $out;
}

function get_char($row, $p_x, $p_y){
global $hp_options, $db, $wbbuserdata, $funccount;
  $funccount++;
  $row['modi'] = 2;
  $row['level'] = 4;
$age = round((time()-$row['char_birth_unix'])/60/60/24);
$max_health = round(($row['stat_kon'] +$row['stat_kon'] +$row['stat_kk'])/(2+$row['modi']));
$max_stam = round(($row['stat_mut'] +$row['stat_int'] +$row['stat_gew'])/(2+$row['modi']));
$max_mana = round(($row['stat_mut'] +$row['stat_kon'] +$row['stat_cha'])/(2+$row['modi']));
$exp_max = (
$row['stat_kon'] +
$row['stat_kk'] +
$row['stat_mut'] +
$row['stat_int'] +
$row['stat_ff'] +
$row['stat_ch'] +
$row['stat_klu'] +
$row['stat_gew']) * 1000;

//(Health) LP: (KO + KO + KK) / 2 + Rassenmodifikator
//(Stamina) AU: (MU + KO + GE) / 2 + Rassenmodifikator
//(Mana) AE: (MU + IN + CH) / 2 + Modifikatoren

  switch($row['char_type']){
  case"2":
          $bg = "grey";
  break;
  case"3":
          $bg = "blue";
  break;
  case"4":
          $bg = "gold";
  break;
  default:
          $bg = "black";
  }


$l_width = 155;
$l_height = 260;
$layer = 0;
$x_pos = $p_x + 70;
$y_pos = $p_y + 10;
eval("\$out .= \"\n".hp_gettemplate("hp_layer")."\";");

$bg = "";
$l_width = 200;
$l_height = 10;
$layer = 30;
$x_pos = $p_x + 50;
$y_pos = $p_y + 280;
$l_content = "<big><b>".$row['char_name']."<small><br />(".$age." D)</small></b></big>";
eval("\$out .= \"\n".hp_gettemplate("hp_centerlayer")."\";");




               //Leben
               $x_pos = $p_x + 45;
               $y_pos = $p_y + 60;
               $out .= status_bar($row['char_hits'], $max_health, "tomato", "L", 1, $x_pos, $y_pos);

               //Leben
               $x_pos = $p_x + 60;
               $y_pos = $p_y + 60;
               $out .= status_bar($row['char_mana'], $max_mana, "royalblue", "M", 1, $x_pos, $y_pos);

               //Stam
               $x_pos = $p_x + 215;
               $y_pos = $p_y + 60;
               $out .= status_bar($row['char_stam'], $max_stam, "silver", "S", 1, $x_pos, $y_pos);

               //EXP
               $x_pos = $p_x + 230;
               $y_pos = $p_y + 60;
               $out .= status_bar($row['char_exp'], $exp_max, "gold", "E", 1, $x_pos, $y_pos);

              $l_width = 260;
              $l_height = 237;

              //Charhintergrund
              $layerarray[] = 0;
              $x_posarray[] = $p_x + 30;
              $y_posarray[] = $p_y - 30;
              $filearray[] = "images/334.gif";

              //Body Gump
              $layerarray[] = 0;
              $x_posarray[] = $p_x + 50;
              $y_posarray[] = $p_y + 20;
              switch($sex){
              case"1":
                $filearray[] = "images/female.gif";
              break;
              default:
                  $filearray[] = "images/male.gif";
              }

              $layerarray[] = 11;
              $x_posarray[] = $p_x + 50;
              $y_posarray[] = $p_y + 20;
              $filearray[] = "all_items/Item141.gif";

              $layerarray[] = 10;
              $x_posarray[] = $p_x + 50;
              $y_posarray[] = $p_y + 20;
              $filearray[] = "all_items/Item119.gif";

              $layerarray[] = 9;
              $x_posarray[] = $p_x + 25;
              $y_posarray[] = $p_y;
              $filearray[] = "all_items/Item112.gif";

              //Charakter Stats

              $l_width = 200;
              $l_height = 100;
              $bg = "teal";
              $layer = 0;
              $l_content = "
              <table rules=\"rows\" frame=\"box\" height=\"100%\" width=\"100%\" border=\"1\">
              <tr><td colspan=\"3\"><b><small>Info:</small></b></td></tr>

              <tr>
              <td>
              <small><b><-o-><br />
              KL: ".$row['stat_klu']."<br />
              WE: ".$row['stat_we']."<br />
              IN: ".$row['stat_int']."<br />
              CH: ".$row['stat_cha']."
              </b></small>
              </td>
              <td>
              <small><b><-B-><br />
              MU: ".$row['stat_mut']."<br />
              KK: ".$row['stat_kk']."<br />
              KO: ".$row['stat_kon']."<br />
              FF: ".$row['stat_ff']."
              </b></small>
              </td>
              <td>
              <small><b><-A-><br />
              Gr.: ".$row['char_size']." ft<br />
              Ge.: ".$row['char_weight']." st<br />
              Hr.: ".$row['char_hair_type'].", ".$row['char_hair_color']."<br />
              Sk.: ".$row['char_skin_color']."
              </b></small>
              </td>
              </tr>

              </table> ";
              $x_pos = $p_x + 60;
              $y_pos = $p_y + 340;
              eval("\$out .= \"\n".hp_gettemplate("hp_layer")."\";");

              //Ausgabe
              $out .= char_layers($filearray, $layerarray, $x_posarray, $y_posarray);

return $out;
}
?>