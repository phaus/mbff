<?php
$hp['footer'] = hp_compressed_output();
$hp['flag_path'] = $sys_conf['img_path']['root'].$sys_conf['img_path']['flags'];
eval("\$hp['set_lang'] = \"".hp_gettemplate("set_lang", $sys_conf['lang'])."\";");
?>