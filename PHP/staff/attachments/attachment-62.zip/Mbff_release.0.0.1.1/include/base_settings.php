<?php
/*
**
Defines f�r die Usereinstellungen.
Amun November 2004

$config_name[] 		= ""; //Array mit Namen der Einstellung 
$config_string[] 	= ""; //Array mit der eindeutigen Bezeichnung (unter dieser der Eintrag abgespeichert wird)
$config_desc[] 		= ""; //Array mit Beschreibung der Einstellung 
$config_typ[] 		= ""; //Array mit Typ der Einstellung (Dropdown/Input/Textfeld/On|Off) 
*/

$config_name[] 		= "Session speichern ?"; 
$config_string[] 	= "cookie"; 
$config_desc[] 		= "Hiermit wird die Session in einer lokalten Cookiedatei auf Ihrem Rechner gespeichert. Befinden Sie innerhalb von 24 Stunden abermals im mbff, so sind Sie bereits eingeloggt !";
$config_typ[] 		= "bool";
?>