<?php
define('_register_email', false);

$hp['style_dir'] 	= "styles/main";
$hp['style_file'] 	= $hp['style_dir']."/style.css";

//================================================================================//
$sys_conf['s_timeout'] = 24 * 60 * 60;
$sys_conf['url'] = 24 * 60 * 60;
$sys_conf['email'] = "mbff@hausswolff.de";

$sys_conf['title'] = "mbff System";
$sys_conf['version'] = "0.0.0.1 alpha";

$sys_conf[img_sys] = "world/system";

$sys_conf['db_level1']['name'] = "mbff_level1";
$sys_conf['db_level1']['host'] = "localhost";
$sys_conf['db_level1']['user'] = "root";
$sys_conf['db_level1']['pass'] = "";

$sys_conf['db_level1']['s_db'] = "sessions";
$sys_conf['db_level1']['s_v_db'] = "sessions_value";
$sys_conf['db_level1']['usr_pre'] = "users_";
$sys_conf['db_level1']['sys_pre'] = "systems_";


$sys_conf['db_level2']['name'] = "mbff_level2";
$sys_conf['db_level2']['host'] = "localhost";
$sys_conf['db_level2']['user'] = "root";
$sys_conf['db_level2']['pass'] = "";

$sys_conf['db_level3']['name'] = "mbff_level3";
$sys_conf['db_level3']['host'] = "localhost";
$sys_conf['db_level3']['user'] = "root";
$sys_conf['db_level3']['pass'] = "";

?>