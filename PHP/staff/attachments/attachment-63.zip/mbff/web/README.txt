verzeichnisse, die auf chmod 777 stehen m�ssen:

/cache/html
/cache/imgs

/tmp
/world/avatars