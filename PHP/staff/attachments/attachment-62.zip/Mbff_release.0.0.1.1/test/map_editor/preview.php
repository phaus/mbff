<body bgcolor="#000000">
<?php
$filename = "map_static.msf";
include($filename);
/*
 Darstellung
*/
$tile_height  = $sys['xpos'] = $sys['ypos'] = 0;
$xspacer = 50;
$yspacer = 40;
$w = 70; 
$h = 35;
$w2 = floor($w/2);
$h2 = floor($h/2);

$layer = $pic = 0;

$offset = 1;
for($y = 0; $y < 45; $y++){
	$layer++;
	for($x = 0; $x < 15; $x++){
		if($y % 2 == 0)
			$sys['xpos'] = $xspacer - $w2 + ($w) * $x ;
		else
			$sys['xpos'] = $xspacer + ($w ) * $x;
			
		$sys['ypos'] = $yspacer + $y*($h2 + $offset) - $tile_height; 
		$para = $map[$x][$y];
		echo "<div style=\"color:#ffffff; text-align:center; vertical-align:top; background-image:url(tile.php?m=".$para['m']."&o=".$para['o']."&u=".$para['u']."&l=".$para['l']."&r=".$para['r']."); position:absolute; z-index:".$layer."; width:70px; height:35px; left:".$sys['xpos']."px;top:".$sys['ypos']."px;\">\n";
		echo "</div>\n";			
	}
	$pic++;
}

?>
</body>