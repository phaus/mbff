# MySQL-Front Dump 2.5
#
# Host: imotep   Database: mbff_level3
# --------------------------------------------------------
# Server version 4.0.18-nt


#
# Table structure for table 'unit_index'
#

DROP TABLE IF EXISTS `unit_index`;
CREATE TABLE `unit_index` (
  `unit_id` int(15) unsigned default '0',
  `unit_name` varchar(100) default NULL,
  `location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'unit_link'
#

DROP TABLE IF EXISTS `unit_link`;
CREATE TABLE `unit_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `unit_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Table structure for table 'vehicle_index'
#

DROP TABLE IF EXISTS `vehicle_index`;
CREATE TABLE `vehicle_index` (
  `vehicle_id` int(15) unsigned default '0',
  `vehicle_name` varchar(100) default NULL,
  `location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Table structure for table 'vehicle_link'
#

DROP TABLE IF EXISTS `vehicle_link`;
CREATE TABLE `vehicle_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `vehicle_id` int(15) unsigned default '0'
) TYPE=MyISAM;

