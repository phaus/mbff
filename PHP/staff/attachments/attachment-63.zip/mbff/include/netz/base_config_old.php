<?php
define('_register_email', true);

$hp['style_dir'] 	= "styles/main";
$hp['style_file'] 	= $hp['style_dir']."/style.css";
//================================================================================//

$sys_conf['img_path']['upload'] = "./world/";
$sys_conf['img_path']['root'] = "./world/";
$sys_conf['img_path']['avatars'] = "avatars/";
$sys_conf['img_path']['flags'] = "system/flags/";

$sys_conf['img_upload']['maxx'] = 100; 
$sys_conf['img_upload']['maxy'] = 100;

$sys_conf['cache_folder'] = "./cache/";

$sys_conf['s_timeout'] = 24 * 60 * 60;
$sys_conf['url'] = "http://mbff.rpg-switch.de";
$sys_conf['email'] = "mbff@hausswolff.de";

$sys_conf['internet_time'] = date("d.m.Y:B")."@";

$sys_conf['title'] = "mbff System";
$sys_conf['version'] = "0.0.0.7";

$sys_conf[img_sys] = "world/system";

$sys_conf['db_level1']['name'] = "usr_web2_1";
$sys_conf['db_level1']['host'] = "localhost";
$sys_conf['db_level1']['user'] = "web2";
$sys_conf['db_level1']['pass'] = "G4TkwwF8";

$sys_conf['db_level1']['s_db'] = "sessions";
$sys_conf['db_level1']['s_v_db'] = "sessions_value";
$sys_conf['db_level1']['usr_pre'] = "users_";
$sys_conf['db_level1']['sys_pre'] = "systems_";


$sys_conf['db_level2']['name'] = "usr_web2_2";
$sys_conf['db_level2']['host'] = "localhost";
$sys_conf['db_level2']['user'] = "web2";
$sys_conf['db_level2']['pass'] = "G4TkwwF8";

$sys_conf['db_level3']['name'] = "usr_web2_3";
$sys_conf['db_level3']['host'] = "localhost";
$sys_conf['db_level3']['user'] = "web2";
$sys_conf['db_level3']['pass'] = "G4TkwwF8";

?>