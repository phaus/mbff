<html>
	<head>
		<title>MBFF MAP TEST (c) 2005 by Amun</title>
	</head>
	<body>
<?php
require("include/class/class_fieldmap.php");
echo "ANSICHT: 
<a href=\"".$PHP_SELF."?type=iso\">ISO</a>&nbsp;&nbsp;
<a href=\"".$PHP_SELF."?type=hex\">HEX</a>&nbsp;&nbsp;
<a href=\"".$PHP_SELF."?type=hex3d\">HEX 3D</a>&nbsp;&nbsp;<hr />";
$system = new c_fieldmap();
$system->set_offset("0", "40");
switch($type){
	case"hex":
		$system->set_map_typ("hex");
		$system->set_tile_size();
		break;
	case"hex3d":
		$system->set_map_typ("hex3d");
		$system->set_tile_size("70", "17");
		break;
	case"iso":
		$system->set_map_typ("iso");
		$system->set_tile_size();
		break;
	default:
		$system->set_map_typ("iso");
		$system->set_tile_size();
}
$system->draw();	
//$system->showclass();
?>
	</body>
</html>
