<?php
##################################################################################
$modules = array("user", "system", "caching");
$funcs = array("login");
$request = array("l_username", "l_password");
$post = array("l_username", "l_password", "root");
##################################################################################
require("./session.php");
$user_id = false;
if($root == "web"){
	$user_id = is_login($l_username, md5($l_password));
	if($user_id != false){
		$login = true;
		header("Location: web/index.php?sid=".$sid);
	}else{
		$login = false;
		$hp[error] = "Login ist fehlgeschlagen !
					<ul>
					<li>Benutzername und Passwort wurden nicht gefunden oder waren nicht richtig.</li>
					<li>Oder Ihr Account ist noch nicht aktiv.</li>
					</ul>";
		eval("\$hp['content']  = \"".hp_gettemplate("error", $sys_conf['lang'], "web")."\";");
		eval("\$index = \"".hp_gettemplate("index", $sys_conf['lang'], "web")."\";");
		echo $index;	
	}
}else{
	$user_id = is_login($l_username, $l_password);
	if($user_id != false){
		header("Location: xml/index.php?sid=".$sid);
	}else{
		$error = "Login ist fehlgeschlagen !\nBenutzername und Passwort wurden nicht gefunden oder waren nicht richtig.\n\nOder Ihr Account ist noch nicht aktiv.\n";
		header("Content-Type: text/xml");
		echo"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		echo "\n<mbff typ=\"login\">\n";
			echo "<sid>-1</sid>\n";
			echo "<error>".$error."</error>\n";
		echo "</mbff>\n";	
	}
}
?>