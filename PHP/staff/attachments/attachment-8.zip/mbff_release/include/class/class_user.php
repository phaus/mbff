<?php


class c_user extends data {

	function c_user($user_id = ""){
		$this->base_data = array('user_id', 'username', 'password', 'date', 'activ');
		$this->index_id = "user_id";
		$this->db_prefix = "users_";
		return $this->data($user_id);
	}
	
	function set_activ(){
		$sql = "UPDATE `".$this->db_prefix."index`
				SET activ = 0
				WHERE ".$this->index_id." = '".$this->data_id."' ";
		$this->class_db->unbuffered_query($sql);
	}
	
	function new_user(){
		$string = strtoupper(substr(getnewsid(),0,10));
		$sql = "SELECT user_id 
				FROM `".$this->db_prefix."index` 
				WHERE username = '".$this->data['username']."' ";
		$result = $this->class_db->query($sql);
		if($this->class_db->num_rows($result) > 0){
			return false;
		}else{
			$sql = "INSERT INTO `".$this->db_prefix."index`
					(".$this->index_id.", username, password, date, activ)
					VALUES
					('".$this->data_id."', '".$this->data['username']."', '".$this->data['password']."', '".time()."', '".$string."')";	
			$this->class_db->query($sql);
			return true;
		}
		$this->class_db->free_result($result);
	}
}
?>