<?php
$sys_conf['document_root'] = "C:/eclipse/workspace/mbff";
?>