# MySQL-Front Dump 2.5
#
# Host: imotep   Database: mbff_level2
# --------------------------------------------------------
# Server version 4.0.18-nt


#
# Table structure for table 'person_index'
#

DROP TABLE IF EXISTS `person_index`;
CREATE TABLE `person_index` (
  `person_id` int(15) unsigned default '0',
  `person_name` varchar(100) default NULL,
  `location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'person_index'
#



#
# Table structure for table 'person_link'
#

DROP TABLE IF EXISTS `person_link`;
CREATE TABLE `person_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `person_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'person_link'
#



#
# Table structure for table 'star_index'
#

DROP TABLE IF EXISTS `star_index`;
CREATE TABLE `star_index` (
  `star_id` int(15) unsigned default '0',
  `star_system_id` int(15) unsigned default '0',
  `star_typ` int(2) unsigned default '0',
  `star_name` varchar(100) default NULL,
  `location` varchar(52) default '0',
  `date` int(15) unsigned default '0',
  `activ` int(1) default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'star_index'
#



#
# Table structure for table 'star_link'
#

DROP TABLE IF EXISTS `star_link`;
CREATE TABLE `star_link` (
  `category` varchar(100) default NULL,
  `value` varchar(100) default NULL,
  `star_id` int(15) unsigned default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'star_link'
#

