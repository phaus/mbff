<?php
require("./include/base_functions.php");
require("./session.php");
$hp['style'] = "background-image: url(images/t.space.gif);";
$hp['footer'] = hp_compressed_output();

switch($action){
	case"activate":
		$user = new c_user($user_id);
		echo $user_id;
		$user->get_data();
		if($s == $user->data['activ']){
			$user->set_activ();
			$username = $user->data['username'];
			eval("\$hp['content']  = \"".hp_gettemplate("register_activ")."\";");
		}else{
			$hp[error] = "Der Account konnte nicht aktiviert werden ! Vielleicht ist er bereits aktiv, oder Sie haben die falschen Daten benutzt !";
			eval("\$hp['content']  = \"".hp_gettemplate("error")."\";");
		}
		break;
		
	case"register":
		if($r_username && $r_password && $r_email){
			$user = new c_user();
			$user->add_entry("username", $r_username);
			$user->add_entry("password", md5($r_password));
			$user->add_entry("email", $r_email);
			
			if($user->new_user()){
				$user->save_data();	
				if(_register_email){
					$user->get_data();
					$user_id = $user->get_id();
					$url = $sys_conf['url'];
					$s_activ = $user->data['activ'];
					eval("\$message  = \"".hp_gettemplate("register_email")."\";");
					eval("\$subject  = \"".hp_gettemplate("register_email_subject")."\";");
					$headers .= "From: ".$url." <".$sys_conf['email'].">\r\n";
					mail($r_email, $subject, $message, $headers);
				}
				eval("\$hp['content']  = \"".hp_gettemplate("register_finish")."\";");
			}else{
				$hp[error] = "Benutzername schon vorhanden !";
				eval("\$hp['content']  .= \"".hp_gettemplate("error")."\";");
				eval("\$hp['content']  .= \"".hp_gettemplate("register")."\";");
			}
		}else{
				$hp[error] = "Es fehlen noch Eingaben !";
				eval("\$hp['content']  .= \"".hp_gettemplate("error")."\";");
				eval("\$hp['content']  .= \"".hp_gettemplate("register")."\";");
		}
		break;	
		
	default:
		eval("\$hp['content']  = \"".hp_gettemplate("register")."\";");
	//inputfelder
}
eval("\$output = \"".hp_gettemplate("index")."\";");
echo $output;
?>