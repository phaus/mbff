<?php
$hp['footer'] = hp_compressed_output();
eval("\$hp['set_lang'] = \"".hp_gettemplate("set_lang", $sys_conf['lang'])."\";");
?>