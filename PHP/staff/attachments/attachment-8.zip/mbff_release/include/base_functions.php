<?php
require("class/class_db.php");
require("base_config.php");
require("class/class_data.php");
require("class/class_user.php");
require("class/class_system.php");
require("class/class_star.php");
require("session_functions.php");

function getnewsid(){
	return md5(uniqid(""));
}

function get_db_count($db, $table, $field, $value){
	$sql = "SELECT ".$field." 
			FROM `".$table."` 
			WHERE ".$value." ";
	$result = $db->unbuffered_query($sql);	
	return $db->num_rows($result);
	$db->free_result($result);
}

function get_db_connect($db_level = 'db_level1'){
global $sys_conf;
	return new db($sys_conf[$db_level]['host'], $sys_conf[$db_level]['user'], $sys_conf[$db_level]['pass'], $sys_conf[$db_level]['name'],$phpversion);
}

//gibt die h�chste g�ltige ID eines DB Eintrages aus
function getnewid($db, $table, $field){
global $funccount;
	$funccount++;	
	$sql = "SELECT ".$field." 
			FROM `".$table."` 
			ORDER BY ".$field." DESC
			LIMIT 0,1";
	$result = $db->unbuffered_query($sql);			
	if($row = $db->fetch_array($result))
		$out = intval($row[$field]) + 1; 
	elseif($db -> num_rows($result) == 0)
		$out = 1;
	else
		$out = false;
	
	return $out;
	$db -> free_result($result);
}

//Funktion um html Template aus zu geben...
function hp_gettemplate($template)
{
global $funccount,$templcount;
	$funccount++;
	$templcount++;
	$templatefolder = "templates/";
	return str_replace("\"","\\\"",implode("",file("templates/".$template.".tpl")));
}

//compressed output
function hp_compressed_output()
{
global $funccount;
$funccount++;

	$encoding = getEnv("HTTP_ACCEPT_ENCODING");
	$useragent = getEnv("HTTP_USER_AGENT");
	$method = trim(getEnv("REQUEST_METHOD"));
	$msie = preg_match("=msie=i", $useragent);
	$gzip = preg_match("=gzip=i", $encoding);
	if ($gzip && ($method != "POST" or !$msie))
	{
		ob_start("ob_gzhandler");
		return "<small style=\"background: #000000;color: #FFFF93;\">gzip</small>";
	}
	else
	{
		ob_start();
		return "-|-";
	}
}

?>