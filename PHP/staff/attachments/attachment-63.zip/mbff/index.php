<?php
##################################################################################
$modules = array("user", "system", "system_list", "caching");
$funcs = array("image");
$get = array("s_lang");
$request = array("s_lang");
$post = array();
##################################################################################
require("./session.php");

$hp['footer'] = hp_compressed_output();
$hp['flag_path'] = "web/".$sys_conf['img_path_root']."/".$sys_conf['img_path_flags'];
$hp['style'] = "background-image: url(web/images/t.space.gif);";

eval("\$hp['set_lang'] = \"".hp_gettemplate("set_lang", $sys_conf['lang'], "web")."\";");

if($user_id > 0){
}else{
	$hp['style'] = "background-image: url(images/t.space.gif);";
	eval("\$hp['content']  = \"".hp_gettemplate("login", $sys_conf['lang'], "web")."\";");
}
///////////////////////////////////////////

eval("\$index = \"".hp_gettemplate("index", $sys_conf['lang'], "web")."\";");
echo $index;
?>
