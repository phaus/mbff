<?php
##################################################################################
$modules = array();
$funcs = array();
$get = array();
$request = array();
$post = array();
##################################################################################
require("./session.php");

$db_obj = get_db_connect('db_level1');

$user_count 		= getnewid($db_obj, $sys_conf['db_level1']['usr_pre']."table", "user_id") - 1;
$system_count = get_db_count($db_obj, $sys_conf['db_level1']['sys_pre']."table", "system_id", "category = 'activ' AND value = '0'");
header("Content-Type: text/xml");
echo"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
echo "<mbff typ=\"info\">\n";
echo "<title>".$sys_conf['title']."</title>\n";
echo "<version>".$sys_conf['version']."</version>\n";
echo "<users>\n";
echo "<count>".$user_count."</count>\n";
echo "<online>".get_db_count($db_obj, $sys_conf['db_level1']['s_db'], "session_start", "session_start + 300 > ".time())."</online>\n";
echo "<activ>".get_db_count($db_obj, $sys_conf['db_level1']['usr_pre']."table", "user_id", "category = 'activ' AND value = '0'")."</activ>\n";
echo"</users>";
echo "<systems>\n";
echo "</systems>\n";
echo "</mbff>\n";
?>