<?php
function is_login($username, $password){
	global $sys_conf, $sid;
	$l_db = new db($sys_conf['db_level1']['host'], $sys_conf['db_level1']['user'], $sys_conf['db_level1']['pass'], $sys_conf['db_level1']['name'],$phpversion);	
	$sql = "SELECT * 
			FROM `".$sys_conf['db_level1']['usr_pre']."index` 
			WHERE username = '".addslashes(htmlspecialchars($_POST['l_username']))."' 
			AND activ = 0";
	
	$result = $l_db->query($sql);	
	//echo $sql."<hr />";
	$password = md5($_POST['l_password']);
	if($row = $l_db->fetch_array($result)){
		if( ($row['password'] == $password)){
			add_session($sid, $row['user_id']);
			$out = $row['user_id'];
		}else{ 
			$out = false; //Password falsch
		}
	}else{
		$out = false; //Benutzername nicht gefunden
	}
	$l_db->free_result($result);
return $out;
}
?>