<?php


class c_system extends data {
	var $class_db2 = "";
	var $db_prefix2 = "";
	var $index_id2 = "";
	var $db_level2 = "db_level2";

	function c_system($system_id = ""){
		$this->base_data = array('system_id', 'system_name', 'system_location', 'date', 'activ');
		$this->index_id = "system_id";
		$this->db_prefix = "systems_";
		return $this->data($system_id);
	}
	
	function get_base_date(){
		//Grunddaten laden
		$sql = "SELECT * 
				FROM `".$this->db_prefix."index` 
				WHERE ".$this->index_id." = '".$this->data_id."' ";
		$result = $this->class_db->query($sql);
		if($row = $this->class_db->fetch_array($result, MYSQL_ASSOC)){
			foreach($row as $key => $part)
				if($key != 'system_location')
					$this->data[$key] = $part;
				else
					$this->data[$key] = unserialize($part);
		}	
	}		

	function set_activ(){
		$sql = "UPDATE `".$this->db_prefix."index`
				SET activ = 0
				WHERE ".$this->index_id." = '".$this->data_id."' ";
		$this->class_db->unbuffered_query($sql);
	}
	
	function new_system(){
		$string = strtoupper(substr(getnewsid(),0,10));
		$sql = "SELECT * 
				FROM `".$this->db_prefix."index` 
				WHERE system_name = '".$this->data['system_name']."' ";
		$result = $this->class_db->query($sql);
		if($this->class_db->num_rows($result) > 0){
			return false;
		}else{
			$sql = "INSERT INTO `".$this->db_prefix."index`
					(".$this->index_id.", system_name, system_location, date, activ)
					VALUES
					('".$this->data_id."', '".$this->data['system_name']."', '".serialize($this->data['system_location'])."', '".time()."', '".$string."')";	
			$this->class_db->unbuffered_query($sql);
		}
		$this->class_db->free_result($result);
	}
	
	function get_system_content(){
		global $sys_conf;
		$system_content = array();
		$this->class_db2 = new db($sys_conf[$this->db_level2]['host'], $sys_conf[$this->db_level2]['user'], $sys_conf[$this->db_level2]['pass'], $sys_conf[$this->db_level2]['name'],$phpversion);
		$this->index_id2 = "star_id";
		$this->db_prefix2 = "star_";
		$sql = "SELECT * 
				FROM `".$this->db_prefix2."index` 
				WHERE ".$this->db_prefix2."system_id = '".$this->data_id."' ";
		$result = $this->class_db2->query($sql);
		while($row = $this->class_db2->fetch_array($result, MYSQL_ASSOC)){
			$loc = unserialize($row[$this->db_prefix2.'location']);
			$system_content[$loc[0]][$loc[1]] = $row;
		}
		echo "<!--\n";
		print_r($system_content);
		echo "-->\n";
		return $system_content;
	}
}
?>